<?php
require_once 'config.php';
require_once 'includes/car_manager.php';
require_once 'includes/favorite_manager.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$merk = isset($_GET['merk']) ? sanitize($_GET['merk']) : '';
$tahun_min = isset($_GET['tahun_min']) ? intval($_GET['tahun_min']) : '';
$tahun_max = isset($_GET['tahun_max']) ? intval($_GET['tahun_max']) : '';
$harga_min = isset($_GET['harga_min']) ? floatval($_GET['harga_min']) : '';
$harga_max = isset($_GET['harga_max']) ? floatval($_GET['harga_max']) : '';

// Build query untuk filter
$cars = $carManager->getAllCarsFiltered($search, $merk, $tahun_min, $tahun_max, $harga_min, $harga_max);

// Get distinct merk untuk dropdown filter
$sql_merk = "SELECT DISTINCT merk FROM mobil WHERE status = 'tersedia' ORDER BY merk";
$stmt_merk = $pdo->query($sql_merk);
$merk_list = $stmt_merk->fetchAll(PDO::FETCH_COLUMN);

// Statistics untuk dashboard
$total_cars = count($cars);
$newest_year = 0;
$oldest_year = 9999;
$price_range_min = 0;
$price_range_max = 0;

if ($total_cars > 0) {
    $prices = array_column($cars, 'harga');
    $years = array_column($cars, 'tahun');
    $newest_year = max($years);
    $oldest_year = min($years);
    $price_range_min = min($prices);
    $price_range_max = max($prices);
}

// Get popular brands
$sql_popular = "SELECT merk, COUNT(*) as count FROM mobil WHERE status = 'tersedia' GROUP BY merk ORDER BY count DESC LIMIT 5";
$stmt_popular = $pdo->query($sql_popular);
$popular_brands = $stmt_popular->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Mobil - Automarket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #3498db;
            --primary-dark: #2980b9;
            --secondary: #e74c3c;
            --success: #2ecc71;
            --warning: #f39c12;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --light-gray: #e9ecef;
        }

        /* ===== Layout fix supaya footer tidak tertutup =====
           - body flex agar footer berada di bawah
           - .page-container flex:1 agar area konten menempati sisa tinggi
        */
        html, body {
            height: 100%;
        }

        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* wrapper utama yang akan menyesuaikan sisa tinggi sehingga footer di bawah */
        .page-container {
            flex: 1 0 auto;
        }

        /* pastikan container memberi ruang bawah untuk footer */
        .container.mt-4 {
            padding-bottom: 60px; /* ruang tambahan agar elemen panjang tidak menutup footer */
        }

        /* ===== Dashboard Stats ===== */
        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border-left: 4px solid var(--primary);
            height: 100%;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .stats-card.success {
            border-left-color: var(--success);
        }

        .stats-card.warning {
            border-left-color: var(--warning);
        }

        .stats-card.danger {
            border-left-color: var(--secondary);
        }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .stats-icon.primary {
            background: rgba(52, 152, 219, 0.1);
            color: var(--primary);
        }

        .stats-icon.success {
            background: rgba(46, 204, 113, 0.1);
            color: var(--success);
        }

        .stats-icon.warning {
            background: rgba(243, 156, 18, 0.1);
            color: var(--warning);
        }

        .stats-icon.danger {
            background: rgba(231, 76, 60, 0.1);
            color: var(--secondary);
        }

        .stats-number {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stats-label {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .price-range {
            font-size: 0.9rem;
            color: var(--gray);
            margin-top: 5px;
        }

        /* ===== Popular Brands ===== */
        .brands-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            height: 100%;
            /* batasi tinggi supaya tidak menutupi footer */
            max-height: 60vh;
            overflow-y: auto;
        }

        .brand-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid var(--light-gray);
        }

        .brand-item:last-child {
            border-bottom: none;
        }

        .brand-name {
            font-weight: 500;
        }

        .brand-count {
            background: var(--primary);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        /* ===== Filter Sidebar ===== */
        .filter-sidebar {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            /* sebelumnya height: fit-content; - ubah agar tidak kebanyakan tinggi */
            max-height: 85vh;
            overflow-y: auto;
            position: sticky;
            top: 20px;
        }

        .filter-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--light-gray);
        }

        .filter-header i {
            color: var(--primary);
            margin-right: 10px;
            font-size: 1.2rem;
        }

        .filter-header h5 {
            margin: 0;
            font-weight: 600;
        }

        .form-label {
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-control, .form-select {
            border-radius: 8px;
            border: 1px solid #dee2e6;
            padding: 10px 15px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(52, 152, 219, 0.25);
        }

        /* ===== Car Cards ===== */
        .car-card {
            transition: all 0.3s ease;
            border: none;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            height: 100%;
        }

        .car-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .car-image-container {
            position: relative;
            overflow: hidden;
            height: 200px;
        }

        .car-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .car-card:hover .car-image {
            transform: scale(1.05);
        }

        .favorite-btn {
            position: absolute;
            top: 12px;
            right: 12px;
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            z-index: 10;
        }

        .favorite-btn:hover {
            background: white;
            transform: scale(1.1);
        }

        .car-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            background: var(--secondary);
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .price-tag {
            color: var(--secondary);
            font-weight: 700;
            font-size: 1.3rem;
            margin-bottom: 0;
        }

        .car-details {
            display: flex;
            align-items: center;
            color: var(--gray);
            font-size: 0.85rem;
            margin-bottom: 8px;
        }

        .car-details i {
            margin-right: 5px;
            width: 16px;
            text-align: center;
        }

        .car-title {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 12px;
            font-size: 1.1rem;
            line-height: 1.3;
        }

        .card-body {
            padding: 20px;
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        /* ===== Results Header ===== */
        .results-header {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .results-count {
            background: var(--primary);
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        /* ===== Buttons ===== */
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-outline-secondary {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-outline-secondary:hover {
            transform: translateY(-2px);
        }

        /* ===== Empty State ===== */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--light-gray);
            margin-bottom: 20px;
        }

        /* ===== Animation ===== */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stats-card, .brands-card, .car-card {
            animation: fadeIn 0.5s ease;
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* small screens adjustments */
        @media (max-width: 767px) {
            .car-image-container { height: 160px; }
            .filter-sidebar { position: static; max-height: none; }
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- page-container agar flex behavior bekerja dan footer selalu berada di bawah -->
    <div class="page-container">
        <div class="container mt-4">
            <!-- Dashboard Stats -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon primary">
                            <i class="fas fa-car"></i>
                        </div>
                        <div class="stats-number"><?php echo $total_cars; ?></div>
                        <div class="stats-label">Total Mobil Tersedia</div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card warning">
                        <div class="stats-icon warning">
                            <i class="fas fa-calendar-plus"></i>
                        </div>
                        <div class="stats-number"><?php echo $newest_year > 0 ? $newest_year : '-'; ?></div>
                        <div class="stats-label">Tahun Terbaru</div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card danger">
                        <div class="stats-icon danger">
                            <i class="fas fa-calendar-minus"></i>
                        </div>
                        <div class="stats-number"><?php echo $oldest_year < 9999 ? $oldest_year : '-'; ?></div>
                        <div class="stats-label">Tahun Tertua</div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-4">
                    <!-- Filter Sidebar -->
                    <div class="filter-sidebar">
                        <div class="filter-header">
                            <i class="fas fa-filter"></i>
                            <h5>Filter Mobil</h5>
                        </div>
                        <form method="GET" action="cars.php">
                            <div class="mb-3">
                                <label class="form-label">Cari</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0">
                                        <i class="fas fa-search text-muted"></i>
                                    </span>
                                    <input type="text" name="search" class="form-control border-start-0" value="<?php echo htmlspecialchars($search); ?>" placeholder="Merk, model...">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Merk</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0">
                                        <i class="fas fa-car text-muted"></i>
                                    </span>
                                    <select name="merk" class="form-select border-start-0">
                                        <option value="">Semua Merk</option>
                                        <?php foreach($merk_list as $m): ?>
                                            <option value="<?php echo htmlspecialchars($m); ?>" <?php echo $merk == $m ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($m); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tahun</label>
                                <div class="row g-2">
                                    <div class="col">
                                        <input type="number" name="tahun_min" class="form-control" value="<?php echo htmlspecialchars($tahun_min); ?>" placeholder="Min: 2000">
                                    </div>
                                    <div class="col">
                                        <input type="number" name="tahun_max" class="form-control" value="<?php echo htmlspecialchars($tahun_max); ?>" placeholder="Max: 2024">
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="form-label">Harga (Rp)</label>
                                <div class="row g-2">
                                    <div class="col">
                                        <input type="number" name="harga_min" class="form-control" value="<?php echo htmlspecialchars($harga_min); ?>" placeholder="Min: 100000000">
                                    </div>
                                    <div class="col">
                                        <input type="number" name="harga_max" class="form-control" value="<?php echo htmlspecialchars($harga_max); ?>" placeholder="Max: 1000000000">
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 mb-2">
                                <i class="fas fa-check me-2"></i>Terapkan Filter
                            </button>
                            <a href="cars.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-redo me-2"></i>Reset
                            </a>
                        </form>
                    </div>

                    <!-- Popular Brands -->
                    <div class="brands-card mt-4">
                        <h6 class="mb-3"><i class="fas fa-fire text-warning me-2"></i>Merk Populer</h6>
                        <?php if (!empty($popular_brands)): ?>
                            <?php foreach($popular_brands as $brand): ?>
                                <div class="brand-item">
                                    <span class="brand-name"><?php echo htmlspecialchars($brand['merk']); ?></span>
                                    <span class="brand-count"><?php echo (int)$brand['count']; ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted">Belum ada data merk populer.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-9 col-md-8">
                    <!-- Results Header -->
                    <div class="results-header">
                        <h4 class="mb-0">Daftar Mobil Tersedia</h4>
                        <span class="results-count"><?php echo count($cars); ?> mobil ditemukan</span>
                    </div>

                    <!-- Cars Grid -->
                    <div class="row">
                        <?php if(empty($cars)): ?>
                            <div class="col-12">
                                <div class="empty-state">
                                    <i class="fas fa-car"></i>
                                    <h5>Tidak ada mobil yang ditemukan</h5>
                                    <p class="text-muted">Coba ubah filter pencarian Anda</p>
                                    <a href="cars.php" class="btn btn-primary mt-3">Reset Filter</a>
                                </div>
                            </div>
                        <?php else: ?>
                            <?php foreach($cars as $car): ?>
                                <div class="col-xl-4 col-lg-6 col-md-6 mb-4">
                                    <div class="card car-card h-100">
                                        <div class="car-image-container">
                                            <?php
                                            // Ambil foto dari tabel foto_mobil (multiple photos)
                                            $photos = $carManager->getCarPhotos($car['id']);
                                            
                                            // Base path untuk cek file
                                            $base_path = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'cars' . DIRECTORY_SEPARATOR;
                                            $web_path = 'uploads/cars/';
                                            
                                            // Prioritaskan foto dari tabel foto_mobil jika ada
                                            if (!empty($photos)) {
                                                $photo_name = $photos[0]['nama_file'];
                                                $full_path = $base_path . $photo_name;
                                                
                                                if (file_exists($full_path)) {
                                                    $image_src = $web_path . $photo_name;
                                                } else {
                                                    // Coba foto utama dari tabel mobil
                                                    if (!empty($car['foto_mobil']) && file_exists($base_path . $car['foto_mobil'])) {
                                                        $image_src = $web_path . $car['foto_mobil'];
                                                    } else {
                                                        $image_src = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';
                                                    }
                                                }
                                            } 
                                            // Jika tidak ada di foto_mobil, cek foto_mobil di tabel mobil
                                            elseif (!empty($car['foto_mobil'])) {
                                                if (file_exists($base_path . $car['foto_mobil'])) {
                                                    $image_src = $web_path . $car['foto_mobil'];
                                                } else {
                                                    $image_src = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';
                                                }
                                            } 
                                            // Default image
                                            else {
                                                $image_src = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';
                                            }
                                            ?>
                                            
                                            <img src="<?php echo htmlspecialchars($image_src); ?>" 
                                                 class="car-image" 
                                                 alt="<?php echo htmlspecialchars($car['merk'] . ' ' . $car['model']); ?>"
                                                 onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'">

                                            <?php if($car['tahun'] >= 2022): ?>
                                                <div class="car-badge">BARU</div>
                                            <?php endif; ?>

                                            <?php if(isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] == 'pembeli'): ?>
                                                <?php $is_favorite = $favoriteManager->isFavorite($_SESSION['user_id'], $car['id']); ?>
                                                <button class="favorite-btn" data-car-id="<?php echo (int)$car['id']; ?>">
                                                    <i class="<?php echo $is_favorite ? 'fas' : 'far'; ?> fa-heart <?php echo $is_favorite ? 'text-danger' : 'text-muted'; ?>"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>

                                        <div class="card-body">
                                            <h6 class="car-title"><?php echo htmlspecialchars($car['merk'] . ' ' . $car['model']); ?></h6>

                                            <div class="car-details">
                                                <div class="me-3">
                                                    <i class="fas fa-calendar-alt"></i> <?php echo (int)$car['tahun']; ?>
                                                </div>
                                                <div class="me-3">
                                                    <i class="fas fa-tachometer-alt"></i> <?php echo number_format($car['kilometer']); ?> km
                                                </div>
                                            </div>

                                            <div class="car-details">
                                                <div class="me-3">
                                                    <i class="fas fa-gas-pump"></i> <?php echo htmlspecialchars(ucfirst($car['bahan_bakar'])); ?>
                                                </div>
                                                <div>
                                                    <i class="fas fa-cog"></i> <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $car['transmisi']))); ?>
                                                </div>
                                            </div>

                                            <div class="mt-auto pt-3">
                                                <p class="price-tag">Rp <?php echo number_format($car['harga'], 0, ',', '.'); ?></p>

                                                <div class="d-grid gap-2 mt-3">
                                                    <a href="car_detail.php?id=<?php echo (int)$car['id']; ?>" class="btn btn-primary btn-sm">
                                                        <i class="fas fa-eye me-1"></i> Lihat Detail
                                                    </a>
                                                    <?php if(isset($_SESSION['user_id'])): ?>
                                                        <a href="messages.php?to=<?php echo (int)$car['penjual_id']; ?>&car=<?php echo (int)$car['id']; ?>" class="btn btn-outline-primary btn-sm">
                                                            <i class="fas fa-comment me-1"></i> Chat Penjual
                                                        </a>
                                                    <?php else: ?>
                                                        <button class="btn btn-outline-primary btn-sm" onclick="showLoginAlert()">
                                                            <i class="fas fa-comment me-1"></i> Chat Penjual
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- end page-container -->

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Favorite functionality
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const carId = this.getAttribute('data-car-id');
                const icon = this.querySelector('i');
                const button = this;

                // Add loading state
                button.disabled = true;
                const originalHTML = icon ? icon.outerHTML : button.innerHTML;
                if (icon) icon.outerHTML = '<div class="loading"></div>';
                else button.innerHTML = '<div class="loading"></div>';

                fetch('includes/favorite_action.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'car_id=' + encodeURIComponent(carId) + '&action=toggle'
                })
                .then(response => response.json())
                .then(data => {
                    // Remove loading state
                    button.disabled = false;
                    button.innerHTML = '';

                    if (data.success) {
                        if (data.is_favorite) {
                            button.innerHTML = '<i class="fas fa-heart text-danger"></i>';
                        } else {
                            button.innerHTML = '<i class="far fa-heart text-muted"></i>';
                        }

                        // Add animation effect
                        button.style.transform = 'scale(1.2)';
                        setTimeout(() => {
                            button.style.transform = 'scale(1)';
                        }, 300);
                    } else {
                        // Restore original state if failed
                        button.innerHTML = originalHTML;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    button.disabled = false;
                    button.innerHTML = originalHTML;
                });
            });
        });

        function showLoginAlert() {
            // Using Bootstrap modal instead of basic alert for better UX
            if (typeof bootstrap !== 'undefined') {
                // Create a modal dynamically
                const modalHtml = `
                    <div class="modal fade" id="loginAlertModal" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Login Diperlukan</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>Silakan login terlebih dahulu untuk chat penjual.</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                    <a href="login.php" class="btn btn-primary">Login</a>
                                </div>
                            </div>
                        </div>
                    </div>
                `;

                // Add modal to body and show it
                document.body.insertAdjacentHTML('beforeend', modalHtml);
                const modal = new bootstrap.Modal(document.getElementById('loginAlertModal'));
                modal.show();

                // Remove modal from DOM after it's hidden
                document.getElementById('loginAlertModal').addEventListener('hidden.bs.modal', function() {
                    this.remove();
                });
            } else {
                alert('Silakan login terlebih dahulu untuk chat penjual');
            }
        }

        // Handle broken images
        document.querySelectorAll('.car-image').forEach(img => {
            img.addEventListener('error', function() {
                this.src = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';
            });
        });

        // Add subtle animation to cards when they come into view
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.car-card');

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, { threshold: 0.1 });

            cards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
                observer.observe(card);
            });
        });
    </script>
</body>
</html>