<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';

// Cek login menggunakan auth system yang sudah ada
if (!$auth->isLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// Cek role admin
if ($_SESSION['role'] != 'admin') {
    header("Location: ../index.php");
    exit();
}

// Filter parameters
$status = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$search = $_GET['search'] ?? '';

// Build query
$sql = "SELECT tb.*, 
               u1.nama_lengkap as nama_pembeli, u1.email as email_pembeli,
               u2.nama_lengkap as nama_penjual, u2.email as email_penjual,
               m.merk, m.model, m.tahun, m.harga as harga_mobil_aktual,
               sp.nama_plan
        FROM transaksi_booking tb
        JOIN users u1 ON tb.pembeli_id = u1.id
        JOIN users u2 ON tb.penjual_id = u2.id
        JOIN mobil m ON tb.mobil_id = m.id
        LEFT JOIN seller_subscriptions ss ON u2.id = ss.seller_id AND ss.status = 'active'
        LEFT JOIN subscription_plans sp ON ss.plan_id = sp.id
        WHERE DATE(tb.created_at) BETWEEN ? AND ?";

$params = [$date_from, $date_to];

if (!empty($status)) {
    $sql .= " AND tb.status = ?";
    $params[] = $status;
}

if (!empty($search)) {
    $sql .= " AND (tb.kode_booking LIKE ? OR u1.nama_lengkap LIKE ? OR u2.nama_lengkap LIKE ? OR m.merk LIKE ? OR m.model LIKE ?)";
    $search_term = "%$search%";
    $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term, $search_term]);
}

$sql .= " ORDER BY tb.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

// Booking statistics
$sql_stats = "SELECT 
                status,
                COUNT(*) as total,
                SUM(jumlah_total) as total_amount
              FROM transaksi_booking
              WHERE DATE(created_at) BETWEEN ? AND ?
              GROUP BY status";
$stmt_stats = $pdo->prepare($sql_stats);
$stmt_stats->execute([$date_from, $date_to]);
$booking_stats = $stmt_stats->fetchAll();

// Total stats
$total_bookings = 0;
$total_amount = 0;
foreach ($booking_stats as $stat) {
    $total_bookings += $stat['total'];
    $total_amount += $stat['total_amount'];
}

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $booking_id = (int)$_POST['booking_id'];
        
        switch ($_POST['action']) {
            case 'confirm':
                $sql = "UPDATE transaksi_booking SET status = 'dikonfirmasi', dikonfirmasi_at = NOW() WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                if ($stmt->execute([$booking_id])) {
                    $_SESSION['success'] = "Booking berhasil dikonfirmasi";
                }
                break;
                
            case 'cancel':
                $alasan = sanitize($_POST['alasan'] ?? '');
                $sql = "UPDATE transaksi_booking SET status = 'dibatalkan', alasan_pembatalan = ?, dibatalkan_at = NOW() WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                if ($stmt->execute([$alasan, $booking_id])) {
                    $_SESSION['success'] = "Booking berhasil dibatalkan";
                }
                break;
                
            case 'complete':
                $sql = "UPDATE transaksi_booking SET status = 'selesai', selesai_at = NOW() WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                if ($stmt->execute([$booking_id])) {
                    $_SESSION['success'] = "Booking berhasil diselesaikan";
                }
                break;
                
            case 'update_payment':
                $status_pembayaran = sanitize($_POST['status_pembayaran']);
                $catatan = sanitize($_POST['catatan'] ?? '');
                
                $sql = "UPDATE transaksi_booking 
                        SET status_pembayaran = ?, catatan_pembayaran = ?
                        WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                if ($stmt->execute([$status_pembayaran, $catatan, $booking_id])) {
                    $_SESSION['success'] = "Status pembayaran berhasil diperbarui";
                }
                break;
        }
        redirect('admin/bookings.php');
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings - Admin Automarket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #34495e;
            --success: #27ae60;
            --info: #3498db;
            --warning: #f39c12;
            --danger: #e74c3c;
        }
        
        body {
            background-color: #f8f9fa;
            font-size: 0.9rem;
        }
        
        .admin-sidebar {
            background: var(--primary);
            color: white;
            min-height: 100vh;
            padding: 0;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }
        
        .admin-sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            transition: all 0.3s;
        }
        
        .admin-sidebar .nav-link:hover, .admin-sidebar .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
            border-left: 4px solid var(--success);
        }
        
        .admin-header {
            background: white;
            border-bottom: 1px solid #e0e0e0;
            padding: 15px 0;
            margin-bottom: 30px;
        }
        
        .stat-card {
            border-radius: 10px;
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
        }
        
        .payment-badge {
            padding: 4px 8px;
            border-radius: 15px;
            font-size: 0.75rem;
        }
        
        .table-responsive {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                <div class="p-3 text-center" style="background: rgba(0,0,0,0.2);">
                    <h4><i class="fas fa-crown me-2"></i>Automarket</h4>
                    <p class="small mb-0">Admin Panel</p>
                    <small class="text-light opacity-75">
                        <i class="fas fa-user-shield me-1"></i>
                        <?php echo $_SESSION['nama_lengkap'] ?? $_SESSION['username']; ?>
                    </small>
                </div>
                
                <nav class="nav flex-column mt-3">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-users me-2"></i> Users
                    </a>
                    <a class="nav-link" href="cars.php">
                        <i class="fas fa-car me-2"></i> Cars
                    </a>
                    <a class="nav-link active" href="bookings.php">
                        <i class="fas fa-calendar-check me-2"></i> Bookings
                    </a>
                    <a class="nav-link" href="subscriptions.php">
                        <i class="fas fa-crown me-2"></i> Subscriptions
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i> Reports
                    </a>
                    <div class="mt-4"></div>
                    <a class="nav-link" href="<?php echo BASE_URL; ?>">
                        <i class="fas fa-home me-2"></i> Main Site
                    </a>
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-0">
                <!-- Header -->
                <div class="admin-header">
                    <div class="container-fluid">
                        <div class="d-flex justify-content-between align-items-center">
                            <h2 class="mb-0">
                                <i class="fas fa-calendar-check text-warning me-2"></i>
                                Bookings Management
                            </h2>
                            <div class="text-end">
                                <small class="text-muted me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('l, d F Y'); ?>
                                </small>
                                <span class="badge bg-success">Online</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid">
                    <div class="p-4">
                        <!-- Header -->
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h2>
                                <i class="fas fa-calendar-check text-warning me-2"></i>
                                Booking Management
                            </h2>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#filterModal">
                                <i class="fas fa-filter me-2"></i>Filter
                            </button>
                        </div>

                        <!-- Messages -->
                        <?php if(isset($_SESSION['success'])): ?>
                            <div class="alert alert-success alert-dismissible fade show mb-4">
                                <i class="fas fa-check-circle me-2"></i>
                                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <!-- Statistics -->
                        <div class="row mb-4">
                            <div class="col-md-3 col-6 mb-3">
                                <div class="card stat-card border-left-primary">
                                    <div class="card-body">
                                        <h6 class="text-muted">Total Bookings</h6>
                                        <h3 class="mb-0"><?php echo $total_bookings; ?></h3>
                                        <small class="text-muted"><?php echo date('d M', strtotime($date_from)); ?> - <?php echo date('d M Y', strtotime($date_to)); ?></small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <div class="card stat-card border-left-success">
                                    <div class="card-body">
                                        <h6 class="text-muted">Total Amount</h6>
                                        <h3 class="mb-0"><?php echo format_rupiah($total_amount); ?></h3>
                                        <small class="text-muted">Total transaksi</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <div class="card stat-card border-left-warning">
                                    <div class="card-body">
                                        <h6 class="text-muted">Pending</h6>
                                        <h3 class="mb-0">
                                            <?php 
                                                $pending = 0;
                                                foreach($booking_stats as $stat) {
                                                    if ($stat['status'] == 'pending') $pending = $stat['total'];
                                                }
                                                echo $pending;
                                            ?>
                                        </h3>
                                        <small class="text-muted">Menunggu konfirmasi</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-6 mb-3">
                                <div class="card stat-card border-left-info">
                                    <div class="card-body">
                                        <h6 class="text-muted">Confirmed</h6>
                                        <h3 class="mb-0">
                                            <?php 
                                                $confirmed = 0;
                                                foreach($booking_stats as $stat) {
                                                    if ($stat['status'] == 'dikonfirmasi') $confirmed = $stat['total'];
                                                }
                                                echo $confirmed;
                                            ?>
                                        </h3>
                                        <small class="text-muted">Sudah dikonfirmasi</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Bookings Table -->
                        <div class="card border-0 shadow-sm">
                            <div class="card-header bg-white py-3">
                                <h5 class="mb-0">All Bookings</h5>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Booking ID</th>
                                                <th>Car Details</th>
                                                <th>Buyer/Seller</th>
                                                <th>Booking Date</th>
                                                <th>Amount</th>
                                                <th>Status</th>
                                                <th>Payment</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($bookings as $booking): ?>
                                            <tr>
                                                <td>
                                                    <strong><code><?php echo $booking['kode_booking']; ?></code></strong><br>
                                                    <small class="text-muted">#<?php echo $booking['id']; ?></small>
                                                </td>
                                                <td>
                                                    <div>
                                                        <strong><?php echo htmlspecialchars($booking['merk'] . ' ' . $booking['model']); ?></strong><br>
                                                        <small class="text-muted"><?php echo $booking['tahun']; ?> • <?php echo format_rupiah($booking['harga_mobil_aktual']); ?></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="small">
                                                        <strong>Buyer:</strong> <?php echo htmlspecialchars($booking['nama_pembeli']); ?><br>
                                                        <strong>Seller:</strong> <?php echo htmlspecialchars($booking['nama_penjual']); ?>
                                                        <?php if($booking['nama_plan']): ?>
                                                            <br><small class="text-success"><i class="fas fa-crown"></i> <?php echo $booking['nama_plan']; ?></small>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php echo date('d M Y', strtotime($booking['tanggal_booking'])); ?><br>
                                                    <small class="text-muted">Created: <?php echo date('H:i', strtotime($booking['created_at'])); ?></small>
                                                </td>
                                                <td class="fw-bold text-success">
                                                    <?php echo format_rupiah($booking['jumlah_total']); ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        switch($booking['status']) {
                                                            case 'pending': echo 'warning'; break;
                                                            case 'dikonfirmasi': echo 'success'; break;
                                                            case 'dibatalkan': echo 'danger'; break;
                                                            case 'selesai': echo 'info'; break;
                                                            default: echo 'secondary';
                                                        }
                                                    ?> status-badge">
                                                        <?php echo $booking['status']; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        switch($booking['status_pembayaran']) {
                                                            case 'lunas': echo 'success'; break;
                                                            case 'menunggu_konfirmasi': echo 'warning'; break;
                                                            case 'belum_bayar': echo 'secondary'; break;
                                                            case 'gagal': echo 'danger'; break;
                                                            default: echo 'secondary';
                                                        }
                                                    ?> payment-badge">
                                                        <?php echo $booking['status_pembayaran'] ?? 'belum_bayar'; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <button class="btn btn-outline-primary" 
                                                                data-bs-toggle="modal" 
                                                                data-bs-target="#viewModal"
                                                                onclick="viewBooking(<?php echo $booking['id']; ?>)">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <?php if($booking['status'] == 'pending'): ?>
                                                            <button class="btn btn-outline-success"
                                                                    onclick="confirmBooking(<?php echo $booking['id']; ?>)">
                                                                <i class="fas fa-check"></i>
                                                            </button>
                                                            <button class="btn btn-outline-danger"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#cancelModal"
                                                                    onclick="setCancelId(<?php echo $booking['id']; ?>)">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        <?php elseif($booking['status'] == 'dikonfirmasi'): ?>
                                                            <button class="btn btn-outline-info"
                                                                    onclick="completeBooking(<?php echo $booking['id']; ?>)">
                                                                <i class="fas fa-flag-checkered"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                        <button class="btn btn-outline-warning"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#paymentModal"
                                                                onclick="setPaymentId(<?php echo $booking['id']; ?>)">
                                                            <i class="fas fa-money-bill"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                            
                                            <?php if(empty($bookings)): ?>
                                            <tr>
                                                <td colspan="8" class="text-center py-4">
                                                    <i class="fas fa-calendar-times fa-2x text-muted mb-3"></i>
                                                    <p class="text-muted">No bookings found for selected filters</p>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer bg-white py-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <small class="text-muted">
                                        Showing <?php echo count($bookings); ?> bookings
                                    </small>
                                    <small class="text-muted">
                                        Last updated: <?php echo date('H:i:s'); ?>
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter Modal -->
    <div class="modal fade" id="filterModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="GET">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-filter me-2"></i>Filter Bookings</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Date From</label>
                            <input type="date" name="date_from" class="form-control" value="<?php echo $date_from; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Date To</label>
                            <input type="date" name="date_to" class="form-control" value="<?php echo $date_to; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="">All Status</option>
                                <option value="pending" <?php echo $status == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="dikonfirmasi" <?php echo $status == 'dikonfirmasi' ? 'selected' : ''; ?>>Confirmed</option>
                                <option value="dibatalkan" <?php echo $status == 'dibatalkan' ? 'selected' : ''; ?>>Cancelled</option>
                                <option value="selesai" <?php echo $status == 'selesai' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Search</label>
                            <input type="text" name="search" class="form-control" placeholder="Booking ID, Name, Car..." value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="bookings.php" class="btn btn-secondary">Reset</a>
                        <button type="submit" class="btn btn-primary">Apply Filter</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Modal -->
    <div class="modal fade" id="viewModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Booking Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="viewModalBody">
                    <!-- Content loaded via AJAX -->
                </div>
            </div>
        </div>
    </div>

    <!-- Cancel Modal -->
    <div class="modal fade" id="cancelModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Cancel Booking</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="cancel">
                        <input type="hidden" name="booking_id" id="cancel_booking_id">
                        <div class="mb-3">
                            <label class="form-label">Reason for Cancellation</label>
                            <textarea name="alasan" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            This action cannot be undone. The buyer will be notified.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger">Cancel Booking</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Update Payment Status</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update_payment">
                        <input type="hidden" name="booking_id" id="payment_booking_id">
                        <div class="mb-3">
                            <label class="form-label">Payment Status</label>
                            <select name="status_pembayaran" class="form-select" required>
                                <option value="belum_bayar">Not Paid</option>
                                <option value="menunggu_konfirmasi">Waiting Confirmation</option>
                                <option value="lunas">Paid</option>
                                <option value="gagal">Failed</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea name="catatan" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-warning">Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function viewBooking(bookingId) {
        fetch(`ajax_get_booking.php?id=${bookingId}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById('viewModalBody').innerHTML = data;
            })
            .catch(error => {
                document.getElementById('viewModalBody').innerHTML = `
                    <div class="alert alert-danger">
                        Error loading booking details
                    </div>
                `;
            });
    }
    
    function confirmBooking(bookingId) {
        if (confirm('Confirm this booking?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const action = document.createElement('input');
            action.name = 'action';
            action.value = 'confirm';
            form.appendChild(action);
            
            const idInput = document.createElement('input');
            idInput.name = 'booking_id';
            idInput.value = bookingId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function completeBooking(bookingId) {
        if (confirm('Mark this booking as completed?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const action = document.createElement('input');
            action.name = 'action';
            action.value = 'complete';
            form.appendChild(action);
            
            const idInput = document.createElement('input');
            idInput.name = 'booking_id';
            idInput.value = bookingId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function setCancelId(bookingId) {
        document.getElementById('cancel_booking_id').value = bookingId;
    }
    
    function setPaymentId(bookingId) {
        document.getElementById('payment_booking_id').value = bookingId;
    }
    </script>
</body>
</html>