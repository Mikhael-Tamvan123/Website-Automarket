<?php
session_start();

// ==================== KONEKSI DATABASE ====================
$host = 'localhost';
$dbname = 'automarket';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// ==================== CEK LOGIN ====================
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location='login.php';</script>";
    exit;
}

$current_user_id = $_SESSION['user_id'];
$current_role = $_SESSION['role'];

// ==================== PARAMETER URL ====================
$to_user_id = $_GET['to'] ?? 0;
$car_id = $_GET['car'] ?? 0;

// Ambil info penerima
$receiver_info = [];
if ($to_user_id) {
    $stmt = $pdo->prepare("SELECT nama_lengkap, foto_profil FROM users WHERE id = ?");
    $stmt->execute([$to_user_id]);
    $receiver_info = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Ambil info mobil jika ada
$car_info = [];
if ($car_id) {
    $stmt = $pdo->prepare("SELECT merk, model, tahun, harga FROM mobil WHERE id = ?");
    $stmt->execute([$car_id]);
    $car_info = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automarket - Chat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .chat-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px 15px 0 0;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255,255,255,0.3);
        }
        .messages-container {
            height: 500px;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .message-bubble {
            max-width: 70%;
            padding: 12px 18px;
            margin-bottom: 15px;
            border-radius: 18px;
            position: relative;
            animation: fadeIn 0.3s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message-sent {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 5px;
        }
        .message-received {
            background: white;
            color: #333;
            margin-right: auto;
            border-bottom-left-radius: 5px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .message-time {
            font-size: 0.75rem;
            opacity: 0.8;
            margin-top: 5px;
        }
        .message-status {
            font-size: 0.7rem;
            margin-left: 5px;
        }
        .car-info-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        .chat-input-container {
            padding: 20px;
            background: white;
            border-top: 1px solid #e9ecef;
        }
        .typing-indicator {
            display: none;
            padding: 10px 15px;
            font-style: italic;
            color: #6c757d;
        }
        .online-dot {
            width: 10px;
            height: 10px;
            background: #28a745;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        .scroll-to-bottom {
            position: fixed;
            bottom: 100px;
            right: 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: none;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 3px 15px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh;">

    <!-- HEADER -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <i class="fas fa-comments me-2"></i>Automarket Chat
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="
                    <?php 
                    if($current_role == 'admin') echo 'admin/dashboard.php';
                    elseif($current_role == 'penjual') echo 'seller/dashboard.php';
                    else echo 'buyer/dashboard.php';
                    ?>
                "><i class="fas fa-tachometer-alt me-1"></i>Dashboard</a>
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Logout</a>
            </div>
        </div>
    </nav>

    <!-- CHAT CONTAINER -->
    <div class="container my-4">
        <div class="chat-container">
            
            <!-- Chat Header -->
            <div class="chat-header">
                <div class="d-flex align-items-center">
                    <?php if (!empty($receiver_info['foto_profil'])): ?>
                        <img src="uploads/profiles/<?= htmlspecialchars($receiver_info['foto_profil']) ?>" 
                             class="user-avatar me-3" 
                             alt="<?= htmlspecialchars($receiver_info['nama_lengkap']) ?>">
                    <?php else: ?>
                        <div class="user-avatar me-3 bg-light d-flex align-items-center justify-content-center">
                            <i class="fas fa-user text-muted"></i>
                        </div>
                    <?php endif; ?>
                    
                    <div class="flex-grow-1">
                        <h5 class="mb-1">
                            <span class="online-dot"></span>
                            <?= htmlspecialchars($receiver_info['nama_lengkap'] ?? 'User') ?>
                        </h5>
                        <small class="opacity-75">
                            <i class="fas fa-circle text-success me-1"></i>Online
                        </small>
                    </div>
                    
                    <?php if (!empty($car_info)): ?>
                    <div class="text-end">
                        <small class="opacity-75">Mobil yang dibicarakan:</small>
                        <div class="fw-bold"><?= htmlspecialchars($car_info['merk'] ?? '') ?> <?= htmlspecialchars($car_info['model'] ?? '') ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Car Info (jika ada) -->
            <?php if (!empty($car_info)): ?>
            <div class="car-info-card mx-3 mt-3">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h6 class="mb-1"><?= htmlspecialchars($car_info['merk']) ?> <?= htmlspecialchars($car_info['model']) ?></h6>
                        <p class="mb-1 text-muted">Tahun <?= htmlspecialchars($car_info['tahun']) ?></p>
                        <p class="mb-0 text-success fw-bold">Rp <?= number_format($car_info['harga'], 0, ',', '.') ?></p>
                    </div>
                    <div class="col-4 text-end">
                        <a href="car_detail.php?id=<?= $car_id ?>" class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-external-link-alt me-1"></i>Lihat Detail
                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Messages Area -->
            <div class="messages-container" id="messagesContainer">
                <!-- Typing Indicator -->
                <div class="typing-indicator" id="typingIndicator">
                    <i class="fas fa-ellipsis-h me-2"></i>
                    <span id="typingUser">User</span> sedang mengetik...
                </div>

                <!-- Messages -->
                <?php
                try {
                    $sql = "SELECT p.*, 
                            u1.nama_lengkap as pengirim_nama,
                            u1.foto_profil as pengirim_foto,
                            u2.nama_lengkap as penerima_nama,
                            m.merk, m.model
                            FROM pesan p 
                            LEFT JOIN users u1 ON p.pengirim_id = u1.id
                            LEFT JOIN users u2 ON p.penerima_id = u2.id
                            LEFT JOIN mobil m ON p.mobil_id = m.id
                            WHERE ((p.pengirim_id = ? AND p.penerima_id = ?) 
                                   OR (p.pengirim_id = ? AND p.penerima_id = ?))
                            " . ($car_id ? "AND p.mobil_id = ?" : "") . "
                            ORDER BY p.created_at ASC";
                    
                    $params = [$current_user_id, $to_user_id, $to_user_id, $current_user_id];
                    if ($car_id) $params[] = $car_id;
                    
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    $messages = $stmt->fetchAll();
                    
                    if (empty($messages)) {
                        echo '
                        <div class="text-center text-muted py-5">
                            <i class="fas fa-comments fa-3x mb-3 opacity-50"></i>
                            <h5>Belum ada pesan</h5>
                            <p>Mulai percakapan dengan mengirim pesan pertama!</p>
                        </div>';
                    } else {
                        foreach($messages as $msg) {
                            $is_sender = ($msg['pengirim_id'] == $current_user_id);
                            $message_class = $is_sender ? 'message-sent' : 'message-received';
                            ?>
                            <div class="message-bubble <?= $message_class ?>">
                                <?php if (!$is_sender): ?>
                                <small class="fw-bold d-block mb-1">
                                    <?= htmlspecialchars($msg['pengirim_nama']) ?>
                                </small>
                                <?php endif; ?>
                                
                                <div class="message-content">
                                    <?= nl2br(htmlspecialchars($msg['pesan'])) ?>
                                </div>
                                
                                <div class="message-time d-flex justify-content-between align-items-center mt-2">
                                    <span>
                                        <?= date('H:i', strtotime($msg['created_at'])) ?>
                                    </span>
                                    <?php if ($is_sender): ?>
                                    <span class="message-status">
                                        <?= $msg['dibaca'] ? '<i class="fas fa-check-double text-info"></i>' : '<i class="fas fa-check text-muted"></i>' ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php
                        }
                    }
                } catch(PDOException $e) {
                    echo '<div class="alert alert-danger m-3">Error: ' . $e->getMessage() . '</div>';
                }
                ?>
            </div>

            <!-- Chat Input -->
            <div class="chat-input-container">
                <form method="POST" action="send_message.php" id="messageForm">
                    <input type="hidden" name="penerima_id" value="<?= $to_user_id ?>">
                    <input type="hidden" name="mobil_id" value="<?= $car_id ?>">
                    
                    <div class="input-group">
                        <textarea name="pesan" class="form-control" rows="1" 
                                  placeholder="Ketik pesan Anda..." 
                                  id="messageInput"
                                  style="resize: none; border-radius: 20px; padding: 12px 20px;"></textarea>
                        <button type="submit" class="btn btn-primary ms-2" 
                                style="border-radius: 50%; width: 50px; height: 50px;">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scroll to Bottom Button -->
    <button class="scroll-to-bottom" id="scrollToBottom" onclick="scrollToBottom()">
        <i class="fas fa-arrow-down"></i>
    </button>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto scroll to bottom
        function scrollToBottom() {
            const container = document.getElementById('messagesContainer');
            container.scrollTop = container.scrollHeight;
        }

        // Show/hide scroll to bottom button
        const messagesContainer = document.getElementById('messagesContainer');
        const scrollButton = document.getElementById('scrollToBottom');

        messagesContainer.addEventListener('scroll', function() {
            const isAtBottom = this.scrollHeight - this.scrollTop === this.clientHeight;
            scrollButton.style.display = isAtBottom ? 'none' : 'flex';
        });

        // Auto resize textarea
        const messageInput = document.getElementById('messageInput');
        messageInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });

        // Auto scroll on new message and page load
        window.addEventListener('load', scrollToBottom);
        
        // Form submission
        document.getElementById('messageForm').addEventListener('submit', function(e) {
            const message = messageInput.value.trim();
            if (message === '') {
                e.preventDefault();
                return;
            }
            // Bisa ditambahkan AJAX di sini untuk real-time messaging
        });

        // Check for new messages every 5 seconds
        setInterval(function() {
            // Implementasi real-time message checking bisa ditambahkan di sini
        }, 5000);
    </script>
</body>
</html>