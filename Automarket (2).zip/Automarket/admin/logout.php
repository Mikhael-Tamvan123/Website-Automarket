<?php
// Automarket/admin/logout.php

session_start();

// Cek apakah sudah login sebagai admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect ke Login.php di root
    header("Location: ../Login.php");
    exit();
}

// Ambil data admin untuk pesan
$admin_nama = $_SESSION['admin_nama'] ?? 'Admin';

// Hapus semua session data admin
unset($_SESSION['admin_logged_in']);
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
unset($_SESSION['admin_nama']);
unset($_SESSION['admin_email']);
unset($_SESSION['admin_role']);

// Hapus semua data session
$_SESSION = array();

// Hapus cookie session
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
    );
}

// Hancurkan session
session_destroy();

// Mulai session baru untuk pesan logout
session_start();
$_SESSION['logout_admin'] = true;
$_SESSION['logout_message'] = "Admin <strong>$admin_nama</strong> telah logout dari sistem.";

// Redirect ke Login.php di root folder
header("Location: ../Login.php");
exit();
?>