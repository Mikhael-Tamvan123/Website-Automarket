<?php
session_start();

// ==================== KONEKSI DATABASE ====================
$host = 'localhost';
$dbname = 'automarket';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

// ==================== CEK LOGIN ====================
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'pembeli') {
    echo "<script>alert('Silakan login terlebih dahulu'); window.location='../login.php';</script>";
    exit;
}

$current_user_id = $_SESSION['user_id'];
$current_role = $_SESSION['role'];

// ==================== PARAMETER URL ====================
$to_user_id = $_GET['to'] ?? 0;
$car_id = $_GET['car'] ?? 0;

// Validasi dan sanitasi input
$to_user_id = filter_var($to_user_id, FILTER_VALIDATE_INT) ? $to_user_id : 0;
$car_id = filter_var($car_id, FILTER_VALIDATE_INT) ? $car_id : 0;

// Ambil info penerima
$receiver_info = [];
if ($to_user_id > 0) {
    $stmt = $pdo->prepare("SELECT id, nama_lengkap, foto_profil FROM users WHERE id = ?");
    $stmt->execute([$to_user_id]);
    $receiver_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Validasi apakah user penerima exists
    if (!$receiver_info) {
        $_SESSION['error'] = "User penerima tidak ditemukan";
        $to_user_id = 0;
    }
}

// Ambil info mobil jika ada dan validasi
$car_info = [];
if ($car_id > 0) {
    $stmt = $pdo->prepare("SELECT id, merk, model, tahun, harga FROM mobil WHERE id = ?");
    $stmt->execute([$car_id]);
    $car_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Validasi apakah mobil exists
    if (!$car_info) {
        $_SESSION['error'] = "Data mobil tidak ditemukan";
        $car_id = 0;
    }
}

// Handle send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $receiver_id = filter_var($_POST['receiver_id'], FILTER_VALIDATE_INT);
    $message_content = trim($_POST['message_content']);
    $mobil_id = isset($_POST['mobil_id']) ? filter_var($_POST['mobil_id'], FILTER_VALIDATE_INT) : null;
    
    // Validasi input
    if ($receiver_id <= 0) {
        $_SESSION['error'] = "Penerima pesan tidak valid";
    } elseif (empty($message_content)) {
        $_SESSION['error'] = "Pesan tidak boleh kosong";
    } else {
        try {
            // Jika mobil_id disediakan, validasi apakah mobil exists
            if ($mobil_id && $mobil_id > 0) {
                $stmt = $pdo->prepare("SELECT id FROM mobil WHERE id = ?");
                $stmt->execute([$mobil_id]);
                $mobil_exists = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$mobil_exists) {
                    $mobil_id = null; // Set ke null jika mobil tidak ditemukan
                }
            } else {
                $mobil_id = null;
            }
            
            // Validasi apakah penerima exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
            $stmt->execute([$receiver_id]);
            $receiver_exists = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$receiver_exists) {
                $_SESSION['error'] = "User penerima tidak ditemukan";
            } else {
                $sql = "INSERT INTO pesan (pengirim_id, penerima_id, mobil_id, pesan, dibaca, created_at) 
                        VALUES (?, ?, ?, ?, 0, NOW())";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$current_user_id, $receiver_id, $mobil_id, $message_content]);
                
                $_SESSION['success'] = "Pesan berhasil dikirim";
                header('Location: messages.php?to=' . $receiver_id . ($mobil_id ? '&car=' . $mobil_id : ''));
                exit;
            }
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            $_SESSION['error'] = "Gagal mengirim pesan. Silakan coba lagi.";
        }
    }
}

// Get conversation partners untuk sidebar
$sql_partners = "SELECT DISTINCT 
    u.id as partner_id,
    u.nama_lengkap as partner_name,
    u.foto_profil as partner_photo,
    (SELECT pesan FROM pesan WHERE (pengirim_id = u.id AND penerima_id = ?) OR (pengirim_id = ? AND penerima_id = u.id) ORDER BY created_at DESC LIMIT 1) as last_message,
    (SELECT created_at FROM pesan WHERE (pengirim_id = u.id AND penerima_id = ?) OR (pengirim_id = ? AND penerima_id = u.id) ORDER BY created_at DESC LIMIT 1) as last_message_time,
    COUNT(CASE WHEN p.dibaca = 0 AND p.penerima_id = ? THEN 1 END) as unread_count
FROM users u
INNER JOIN pesan p ON (u.id = p.pengirim_id OR u.id = p.penerima_id)
WHERE (p.pengirim_id = ? OR p.penerima_id = ?) AND u.id != ?
ORDER BY last_message_time DESC";

$stmt_partners = $pdo->prepare($sql_partners);
$stmt_partners->execute([$current_user_id, $current_user_id, $current_user_id, $current_user_id, $current_user_id, $current_user_id, $current_user_id, $current_user_id]);
$conversation_partners = $stmt_partners->fetchAll(PDO::FETCH_ASSOC);

// Count total unread messages
$unread_sql = "SELECT COUNT(*) FROM pesan WHERE penerima_id = ? AND dibaca = 0";
$unread_stmt = $pdo->prepare($unread_sql);
$unread_stmt->execute([$current_user_id]);
$unread_count = $unread_stmt->fetchColumn();

// Mark messages as read for current conversation
if ($to_user_id > 0) {
    $mark_read_sql = "UPDATE pesan SET dibaca = 1 WHERE penerima_id = ? AND pengirim_id = ? AND dibaca = 0";
    $mark_read_stmt = $pdo->prepare($mark_read_sql);
    $mark_read_stmt->execute([$current_user_id, $to_user_id]);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan - Automarket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .chat-main-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
            height: 75vh;
        }
        .conversation-sidebar {
            width: 350px;
            border-right: 1px solid #dee2e6;
            background: #f8f9fa;
            height: 100%;
            overflow-y: auto;
        }
        .chat-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .conversation-item {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
            cursor: pointer;
            transition: background-color 0.3s ease;
            background: white;
        }
        .conversation-item:hover {
            background-color: #e9ecef;
        }
        .conversation-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .conversation-item.unread {
            background-color: #e3f2fd;
            border-left: 4px solid #3498db;
        }
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-bottom: 1px solid #dee2e6;
        }
        .message-bubble {
            max-width: 70%;
            margin-bottom: 15px;
            padding: 12px 18px;
            border-radius: 18px;
            position: relative;
            animation: fadeIn 0.3s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message-sent {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 5px;
        }
        .message-received {
            background: white;
            color: #333;
            margin-right: auto;
            border-bottom-left-radius: 5px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .message-time {
            font-size: 0.75rem;
            opacity: 0.8;
            margin-top: 5px;
        }
        .chat-input-container {
            padding: 20px;
            background: white;
            border-top: 1px solid #dee2e6;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255,255,255,0.3);
        }
        .user-avatar-sidebar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        .empty-state {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
            text-align: center;
            color: #6c757d;
            padding: 40px;
        }
        .car-info-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        .online-dot {
            width: 10px;
            height: 10px;
            background: #28a745;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
        }
        .typing-indicator {
            display: none;
            padding: 10px;
            color: #666;
            font-style: italic;
            font-size: 0.9rem;
        }
        .typing-indicator.show {
            display: block;
        }
        .navbar-brand {
            font-weight: 700;
            color: white !important;
        }
        .nav-link {
            transition: all 0.3s ease;
        }
        .nav-link:hover {
            transform: translateY(-2px);
            color: #fff !important;
        }
    </style>
</head>
<body>
    <!-- Custom Header -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-car me-2 text-primary"></i>
                <span class="fw-bold" style="color: #2c3e50;">Automarket</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../cars.php">
                            <i class="fas fa-search me-1"></i>Cari Mobil
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="favorites.php"><i class="fas fa-heart me-2"></i>Favorit</a></li>
                            <li><a class="dropdown-item" href="my_bookings.php"><i class="fas fa-calendar-check me-2"></i>Booking Saya</a></li>
                            <li><a class="dropdown-item active" href="messages.php"><i class="fas fa-comments me-2"></i>Pesan</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-cog me-2"></i>Pengaturan Profil</a></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Keluar</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 mb-4">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <?php if (!empty($_SESSION['foto_profil'])): ?>
                                <img src="../uploads/profiles/<?php echo $_SESSION['foto_profil']; ?>" class="user-avatar" alt="Profile" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #667eea;">
                            <?php else: ?>
                                <div class="user-avatar mx-auto bg-light d-flex align-items-center justify-content-center" style="width: 80px; height: 80px; border-radius: 50%;">
                                    <i class="fas fa-user fa-2x text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></h5>
                        <p class="text-muted mb-3">Pembeli</p>
                        
                        <div class="list-group list-group-flush">
                            <a href="dashboard.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                            <a href="favorites.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-heart me-2"></i>Favorit Saya
                            </a>
                            <a href="my_bookings.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-calendar-check me-2"></i>Booking Saya
                            </a>
                            <a href="messages.php" class="list-group-item list-group-item-action active">
                                <i class="fas fa-comments me-2"></i>Pesan
                                <?php if ($unread_count > 0): ?>
                                    <span class="badge bg-danger ms-1"><?php echo $unread_count; ?></span>
                                <?php endif; ?>
                            </a>
                            <a href="../profile.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-cog me-2"></i>Pengaturan Profil
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h3 mb-0"><i class="fas fa-comments me-2 text-primary"></i>Pesan Saya</h1>
                    <div>
                        <span class="badge bg-primary fs-6"><?php echo count($conversation_partners); ?> Percakapan</span>
                        <?php if ($unread_count > 0): ?>
                            <span class="badge bg-danger fs-6 ms-2"><?php echo $unread_count; ?> Belum Dibaca</span>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="chat-main-container">
                    <div class="d-flex h-100">
                        <!-- Conversation List -->
                        <div class="conversation-sidebar">
                            <?php if (!empty($conversation_partners)): ?>
                                <?php foreach ($conversation_partners as $partner): ?>
                                    <div class="conversation-item <?php echo ($to_user_id == $partner['partner_id']) ? 'active' : ''; ?> <?php echo $partner['unread_count'] > 0 ? 'unread' : ''; ?>" 
                                         onclick="window.location.href='messages.php?to=<?php echo $partner['partner_id']; ?>'">
                                        <div class="d-flex align-items-center">
                                            <div class="me-3">
                                                <?php if (!empty($partner['partner_photo'])): ?>
                                                    <img src="../uploads/profiles/<?php echo $partner['partner_photo']; ?>" class="user-avatar-sidebar" alt="<?php echo htmlspecialchars($partner['partner_name']); ?>">
                                                <?php else: ?>
                                                    <div class="user-avatar-sidebar bg-light d-flex align-items-center justify-content-center">
                                                        <i class="fas fa-user text-muted"></i>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($partner['partner_name']); ?></h6>
                                                <p class="mb-1 text-muted small">
                                                    <?php echo !empty($partner['last_message']) ? htmlspecialchars(substr($partner['last_message'], 0, 30)) . '...' : 'Mulai percakapan...'; ?>
                                                </p>
                                                <?php if ($partner['unread_count'] > 0): ?>
                                                    <span class="badge bg-primary"><?php echo $partner['unread_count']; ?> baru</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div>
                                        <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                                        <p>Belum ada percakapan</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Chat Area -->
                        <div class="chat-area">
                            <?php if ($to_user_id && !empty($receiver_info)): ?>
                                <!-- Chat Header -->
                                <div class="chat-header">
                                    <div class="d-flex align-items-center">
                                        <?php if (!empty($receiver_info['foto_profil'])): ?>
                                            <img src="../uploads/profiles/<?php echo $receiver_info['foto_profil']; ?>" class="user-avatar me-3" alt="<?php echo htmlspecialchars($receiver_info['nama_lengkap']); ?>">
                                        <?php else: ?>
                                            <div class="user-avatar me-3 bg-light d-flex align-items-center justify-content-center">
                                                <i class="fas fa-user text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="flex-grow-1">
                                            <h5 class="mb-1">
                                                <span class="online-dot"></span>
                                                <?php echo htmlspecialchars($receiver_info['nama_lengkap']); ?>
                                            </h5>
                                            <small class="opacity-75">
                                                <i class="fas fa-circle text-success me-1"></i>Online
                                            </small>
                                        </div>
                                        
                                        <?php if (!empty($car_info)): ?>
                                        <div class="text-end">
                                            <small class="opacity-75">Mobil yang dibicarakan:</small>
                                            <div class="fw-bold"><?php echo htmlspecialchars($car_info['merk'] ?? '') ?> <?php echo htmlspecialchars($car_info['model'] ?? '') ?></div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Car Info (jika ada) -->
                                <?php if (!empty($car_info)): ?>
                                <div class="car-info-card">
                                    <div class="row align-items-center">
                                        <div class="col-8">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($car_info['merk']) ?> <?php echo htmlspecialchars($car_info['model']) ?></h6>
                                            <p class="mb-1 text-muted">Tahun <?php echo htmlspecialchars($car_info['tahun']) ?></p>
                                            <p class="mb-0 text-success fw-bold">Rp <?php echo number_format($car_info['harga'], 0, ',', '.') ?></p>
                                        </div>
                                        <div class="col-4 text-end">
                                            <a href="../car_detail.php?id=<?php echo $car_id ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-external-link-alt me-1"></i>Lihat Detail
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Messages Area -->
                                <div class="chat-messages" id="chatMessages">
                                    <?php
                                    try {
                                        $sql = "SELECT p.*, 
                                                u1.nama_lengkap as pengirim_nama,
                                                u1.foto_profil as pengirim_foto,
                                                u2.nama_lengkap as penerima_nama,
                                                m.merk, m.model
                                                FROM pesan p 
                                                LEFT JOIN users u1 ON p.pengirim_id = u1.id
                                                LEFT JOIN users u2 ON p.penerima_id = u2.id
                                                LEFT JOIN mobil m ON p.mobil_id = m.id
                                                WHERE ((p.pengirim_id = ? AND p.penerima_id = ?) 
                                                       OR (p.pengirim_id = ? AND p.penerima_id = ?))
                                                " . ($car_id ? "AND (p.mobil_id = ? OR p.mobil_id IS NULL)" : "") . "
                                                ORDER BY p.created_at ASC";
                                        
                                        $params = [$current_user_id, $to_user_id, $to_user_id, $current_user_id];
                                        if ($car_id) $params[] = $car_id;
                                        
                                        $stmt = $pdo->prepare($sql);
                                        $stmt->execute($params);
                                        $messages = $stmt->fetchAll();
                                        
                                        if (empty($messages)) {
                                            echo '
                                            <div class="empty-state">
                                                <div>
                                                    <i class="fas fa-comments fa-3x mb-3 opacity-50"></i>
                                                    <h5>Belum ada pesan</h5>
                                                    <p>Mulai percakapan dengan mengirim pesan pertama!</p>
                                                </div>
                                            </div>';
                                        } else {
                                            foreach($messages as $msg) {
                                                $is_sender = ($msg['pengirim_id'] == $current_user_id);
                                                $message_class = $is_sender ? 'message-sent' : 'message-received';
                                                ?>
                                                <div class="message-bubble <?php echo $message_class ?>">
                                                    <?php if (!$is_sender): ?>
                                                    <small class="fw-bold d-block mb-1">
                                                        <?php echo htmlspecialchars($msg['pengirim_nama']) ?>
                                                    </small>
                                                    <?php endif; ?>
                                                    
                                                    <div class="message-content">
                                                        <?php echo nl2br(htmlspecialchars($msg['pesan'])) ?>
                                                    </div>
                                                    
                                                    <div class="message-time d-flex justify-content-between align-items-center mt-2">
                                                        <span>
                                                            <?php echo date('H:i', strtotime($msg['created_at'])) ?>
                                                        </span>
                                                        <?php if ($is_sender): ?>
                                                        <span class="message-status">
                                                            <?php echo $msg['dibaca'] ? '<i class="fas fa-check-double text-info"></i>' : '<i class="fas fa-check text-muted"></i>' ?>
                                                        </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        }
                                    } catch(PDOException $e) {
                                        echo '<div class="alert alert-danger m-3">Error: ' . $e->getMessage() . '</div>';
                                    }
                                    ?>
                                    
                                    <!-- Typing Indicator -->
                                    <div id="typingIndicator" class="typing-indicator">
                                        <i class="fas fa-pencil-alt me-1"></i>
                                        <span id="typingUserName"></span> sedang mengetik...
                                    </div>
                                </div>

                                <!-- Chat Input -->
                                <div class="chat-input-container">
                                    <form method="POST" action="messages.php?to=<?php echo $to_user_id . ($car_id ? '&car=' . $car_id : ''); ?>" id="messageForm">
                                        <input type="hidden" name="receiver_id" value="<?php echo $to_user_id ?>">
                                        <input type="hidden" name="mobil_id" value="<?php echo $car_id ?>">
                                        
                                        <div class="input-group">
                                            <textarea name="message_content" class="form-control" rows="1" 
                                                      placeholder="Ketik pesan Anda..." 
                                                      id="messageInput"
                                                      style="resize: none; border-radius: 20px; padding: 12px 20px;"></textarea>
                                            <button type="submit" name="send_message" class="btn btn-primary ms-2" 
                                                    style="border-radius: 50%; width: 50px; height: 50px;">
                                                <i class="fas fa-paper-plane"></i>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            <?php else: ?>
                                <!-- Empty Chat State -->
                                <div class="empty-state flex-grow-1">
                                    <div>
                                        <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                                        <h5>Pilih Percakapan</h5>
                                        <p class="text-muted">Pilih percakapan dari daftar di sebelah kiri untuk mulai mengobrol</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto scroll to bottom
        function scrollToBottom() {
            const container = document.getElementById('chatMessages');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        }

        // Auto resize textarea
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.addEventListener('input', function() {
                this.style.height = 'auto';
                this.style.height = (this.scrollHeight) + 'px';
            });
        }

        // Auto scroll on page load
        window.addEventListener('load', scrollToBottom);

        // AJAX untuk load messages baru tanpa refresh
        let lastMessageId = 0;
        let isTyping = false;
        let typingTimeout = null;
        
        // Get last message ID
        const messageBubbles = document.querySelectorAll('.message-bubble');
        if (messageBubbles.length > 0) {
            lastMessageId = <?php echo !empty($messages) ? end($messages)['id'] : 0; ?>;
        }

        // Check for new messages using AJAX
        function checkNewMessages() {
            if (!<?php echo $to_user_id ? 'true' : 'false'; ?> || isTyping) {
                return;
            }

            const xhr = new XMLHttpRequest();
            xhr.open('GET', `check_messages.php?conversation_id=<?php echo $to_user_id ?>&car_id=<?php echo $car_id ?>&last_id=${lastMessageId}`, true);
            
            xhr.onload = function() {
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        if (response.success && response.new_messages && response.new_messages.length > 0) {
                            // Update last message ID
                            lastMessageId = response.last_message_id;
                            
                            // Add new messages to chat
                            const chatMessages = document.getElementById('chatMessages');
                            response.new_messages.forEach(msg => {
                                const messageClass = msg.is_sender ? 'message-sent' : 'message-received';
                                const messageHtml = `
                                    <div class="message-bubble ${messageClass}">
                                        ${!msg.is_sender ? `<small class="fw-bold d-block mb-1">${msg.sender_name}</small>` : ''}
                                        <div class="message-content">${msg.message}</div>
                                        <div class="message-time d-flex justify-content-between align-items-center mt-2">
                                            <span>${msg.time}</span>
                                            ${msg.is_sender ? `<span class="message-status">
                                                <i class="fas fa-check text-muted"></i>
                                            </span>` : ''}
                                        </div>
                                    </div>
                                `;
                                
                                chatMessages.insertAdjacentHTML('beforeend', messageHtml);
                            });
                            
                            // Scroll to bottom
                            scrollToBottom();
                            
                            // Play notification sound
                            playNotificationSound();
                        }
                        
                        // Update unread count if provided
                        if (response.unread_count !== undefined) {
                            updateUnreadCount(response.unread_count);
                        }
                        
                    } catch (e) {
                        console.error('Error parsing response:', e);
                    }
                }
            };
            
            xhr.send();
        }

        // Play notification sound
        function playNotificationSound() {
            try {
                const audio = new Audio('notification.mp3');
                audio.play().catch(e => console.log('Audio play failed:', e));
            } catch (e) {
                console.log('Notification sound error:', e);
            }
        }

        // Update unread count badge
        function updateUnreadCount(count) {
            const badge = document.querySelector('.badge.bg-danger.ms-1');
            const sidebarBadge = document.querySelector('.badge.bg-danger.fs-6.ms-2');
            
            if (badge) {
                if (count > 0) {
                    badge.textContent = count;
                    badge.style.display = 'inline';
                } else {
                    badge.style.display = 'none';
                }
            }
            
            if (sidebarBadge) {
                if (count > 0) {
                    sidebarBadge.textContent = count + ' Belum Dibaca';
                    sidebarBadge.style.display = 'inline';
                } else {
                    sidebarBadge.style.display = 'none';
                }
            }
        }

        // Start checking for new messages (every 3 seconds)
        setInterval(checkNewMessages, 3000);

        // Prevent auto-refresh when typing
        let typingTimer;
        const typingDelay = 2000; // 2 seconds
        
        if (messageInput) {
            messageInput.addEventListener('input', function() {
                isTyping = true;
                
                // Clear previous timer
                clearTimeout(typingTimer);
                
                // Set new timer
                typingTimer = setTimeout(() => {
                    isTyping = false;
                }, typingDelay);
            });
            
            messageInput.addEventListener('blur', function() {
                isTyping = false;
            });
        }

        // Handle form submission
        const messageForm = document.getElementById('messageForm');
        if (messageForm) {
            messageForm.addEventListener('submit', function(e) {
                const messageInput = document.getElementById('messageInput');
                if (!messageInput || messageInput.value.trim() === '') {
                    e.preventDefault();
                    return false;
                }
            });
        }

        // Mark conversation as read when opened
        function markConversationAsRead(userId) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'mark_read.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send(`user_id=${userId}`);
        }

        // Mark as read when conversation is active
        if (<?php echo $to_user_id ? 'true' : 'false'; ?>) {
            markConversationAsRead(<?php echo $to_user_id; ?>);
        }
    </script>
</body>
</html>