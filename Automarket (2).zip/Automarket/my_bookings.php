<?php
session_start();
require_once 'config.php';

// Cek apakah user sudah login sebagai pembeli
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pembeli') {
    header("Location: login.php");
    exit();
}

$pembeli_id = $_SESSION['user_id'];

// Ambil data bookings pembeli
$sql = "SELECT b.*, m.merk, m.model, m.plat_mobil, m.gambar, u.nama_lengkap as penjual_nama, u.no_telepon as penjual_telepon
        FROM transaksi_booking b
        JOIN mobil m ON b.mobil_id = m.id
        JOIN users u ON b.penjual_id = u.id
        WHERE b.pembeli_id = ?
        ORDER BY b.created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $pembeli_id);
$stmt->execute();
$result = $stmt->get_result();
$bookings = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Saya - Automarket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .booking-card {
            border-left: 4px solid #3498db;
            margin-bottom: 20px;
        }
        .booking-card.pending {
            border-left-color: #f39c12;
        }
        .booking-card.confirmed {
            border-left-color: #27ae60;
        }
        .booking-card.cancelled {
            border-left-color: #e74c3c;
        }
        .booking-card.completed {
            border-left-color: #3498db;
        }
        .car-image {
            height: 120px;
            object-fit: cover;
            width: 100%;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php 
    if (file_exists('includes/navbar.php')) {
        include 'includes/navbar.php'; 
    }
    ?>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-calendar-check me-2"></i>Booking Saya</h2>
            <a href="cars.php" class="btn btn-primary">
                <i class="fas fa-car me-1"></i> Cari Mobil Lain
            </a>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($bookings)): ?>
            <div class="card text-center py-5">
                <div class="card-body">
                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                    <h5 class="card-title">Belum ada booking</h5>
                    <p class="card-text">Anda belum melakukan booking mobil</p>
                    <a href="cars.php" class="btn btn-primary">
                        <i class="fas fa-car me-1"></i> Cari Mobil
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach($bookings as $booking): ?>
                <div class="col-md-6">
                    <div class="card booking-card <?php echo $booking['status']; ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title mb-0">
                                    <?php echo htmlspecialchars($booking['merk'] . ' ' . $booking['model']); ?>
                                </h5>
                                <span class="badge bg-<?php 
                                    switch($booking['status']) {
                                        case 'confirmed': echo 'success'; break;
                                        case 'cancelled': echo 'danger'; break;
                                        case 'completed': echo 'info'; break;
                                        default: echo 'warning';
                                    }
                                ?>">
                                    <?php 
                                    $status_text = [
                                        'pending' => 'Menunggu',
                                        'confirmed' => 'Dikonfirmasi',
                                        'cancelled' => 'Dibatalkan',
                                        'completed' => 'Selesai'
                                    ];
                                    echo $status_text[$booking['status']] ?? ucfirst($booking['status']);
                                    ?>
                                </span>
                            </div>

                            <div class="row">
                                <?php if (!empty($booking['gambar'])): ?>
                                <div class="col-4">
                                    <img src="uploads/<?php echo htmlspecialchars($booking['gambar']); ?>" 
                                         class="car-image rounded" 
                                         alt="<?php echo htmlspecialchars($booking['merk']); ?>">
                                </div>
                                <?php endif; ?>
                                <div class="<?php echo !empty($booking['gambar']) ? 'col-8' : 'col-12'; ?>">
                                    <div class="booking-details">
                                        <p class="mb-2">
                                            <i class="fas fa-car me-2 text-muted"></i>
                                            <strong>Plat:</strong> <?php echo htmlspecialchars($booking['plat_mobil']); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-user me-2 text-muted"></i>
                                            <strong>Penjual:</strong> <?php echo htmlspecialchars($booking['penjual_nama']); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-calendar me-2 text-muted"></i>
                                            <strong>Tanggal Booking:</strong> 
                                            <?php echo date('d M Y', strtotime($booking['tanggal_booking'])); ?>
                                        </p>
                                        <p class="mb-2">
                                            <i class="fas fa-clock me-2 text-muted"></i>
                                            <strong>Lama Sewa:</strong> <?php echo $booking['lama_sewa']; ?> hari
                                        </p>
                                        <?php if (!empty($booking['penjual_telepon'])): ?>
                                        <p class="mb-2">
                                            <i class="fas fa-phone me-2 text-muted"></i>
                                            <strong>Telp Penjual:</strong> 
                                            <a href="https://wa.me/<?php echo htmlspecialchars($booking['penjual_telepon']); ?>" 
                                               class="text-decoration-none" target="_blank">
                                                <?php echo htmlspecialchars($booking['penjual_telepon']); ?>
                                                <i class="fab fa-whatsapp ms-1 text-success"></i>
                                            </a>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <?php if (!empty($booking['catatan'])): ?>
                            <div class="mt-3 p-3 bg-light rounded">
                                <strong><i class="fas fa-sticky-note me-2"></i>Catatan:</strong>
                                <?php echo htmlspecialchars($booking['catatan']); ?>
                            </div>
                            <?php endif; ?>

                            <div class="mt-3 pt-3 border-top">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Dibooking pada: <?php echo date('d M Y H:i', strtotime($booking['created_at'])); ?>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-4 text-center">
                <p class="text-muted">
                    Total: <strong><?php echo count($bookings); ?></strong> booking
                </p>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>