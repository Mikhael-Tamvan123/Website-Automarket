<?php
// Perbaiki path config.php
require_once __DIR__ . '/../includes/db_config.php';

// Redirect jika belum login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Redirect jika bukan pembeli
if ($user_role !== 'pembeli') {
    header('Location: ../index.php');
    exit();
}

// Query data untuk dashboard pembeli
try {
    // Statistik utama - SUDAH DIPERBAIKI: messages -> pesan
    $stats_sql = "SELECT 
        (SELECT COUNT(*) FROM favorit WHERE pembeli_id = ?) as total_favorit,
        (SELECT COUNT(*) FROM transaksi_booking WHERE pembeli_id = ? AND status IN ('pending', 'confirmed')) as total_booking_aktif,
        (SELECT COUNT(*) FROM pesan WHERE penerima_id = ? AND dibaca = 0) as total_pesan_belum_dibaca,
        (SELECT COUNT(*) FROM transaksi_booking WHERE pembeli_id = ? AND status = 'completed') as total_transaksi_selesai";
    
    $stmt = $pdo->prepare($stats_sql);
    $stmt->execute([$user_id, $user_id, $user_id, $user_id]);
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Mobil favorit terbaru - QUERY DIPERBAIKI untuk mendapatkan foto
    $favorit_sql = "SELECT m.*, f.created_at as favorit_date, 
                           u.nama_lengkap as penjual_nama,
                           (SELECT nama_file FROM foto_mobil WHERE mobil_id = m.id ORDER BY urutan LIMIT 1) as foto_utama,
                           COALESCE(
                               (SELECT nama_file FROM foto_mobil WHERE mobil_id = m.id ORDER BY urutan LIMIT 1),
                               m.foto_mobil
                           ) as foto_mobil_utama
                    FROM favorit f 
                    JOIN mobil m ON f.mobil_id = m.id 
                    JOIN users u ON m.penjual_id = u.id 
                    WHERE f.pembeli_id = ? 
                    ORDER BY f.created_at DESC 
                    LIMIT 4";
    $stmt = $pdo->prepare($favorit_sql);
    $stmt->execute([$user_id]);
    $mobil_favorit = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Booking aktif - QUERY DIPERBAIKI untuk mendapatkan foto
    $booking_sql = "SELECT tb.*, m.merk, m.model, m.tahun, m.harga,
                           u.nama_lengkap as penjual_nama,
                           COALESCE(
                               (SELECT nama_file FROM foto_mobil WHERE mobil_id = m.id ORDER BY urutan LIMIT 1),
                               m.foto_mobil
                           ) as foto_mobil_utama
                    FROM transaksi_booking tb
                    JOIN mobil m ON tb.mobil_id = m.id
                    JOIN users u ON tb.penjual_id = u.id
                    WHERE tb.pembeli_id = ? AND tb.status IN ('pending', 'confirmed')
                    ORDER BY tb.created_at DESC 
                    LIMIT 5";
    $stmt = $pdo->prepare($booking_sql);
    $stmt->execute([$user_id]);
    $booking_aktif = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Pesan terbaru - SUDAH DIPERBAIKI: messages -> pesan
    $pesan_sql = "SELECT p.*, 
                         u.nama_lengkap as pengirim_nama,
                         m.merk, m.model
                  FROM pesan p
                  JOIN users u ON p.pengirim_id = u.id
                  LEFT JOIN mobil m ON p.mobil_id = m.id
                  WHERE p.penerima_id = ? 
                  ORDER BY p.created_at DESC 
                  LIMIT 5";
    $stmt = $pdo->prepare($pesan_sql);
    $stmt->execute([$user_id]);
    $pesan_terbaru = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Notifikasi terbaru
    $notifikasi_sql = "SELECT * FROM notifikasi 
                      WHERE user_id = ? 
                      ORDER BY created_at DESC 
                      LIMIT 5";
    $stmt = $pdo->prepare($notifikasi_sql);
    $stmt->execute([$user_id]);
    $notifikasi = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pembeli - Automarket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --accent: #e74c3c;
            --success: #27ae60;
            --warning: #f39c12;
            --light: #f8f9fa;
        }

        body {
            background-color: #f5f6fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s ease;
            border-left: 4px solid var(--secondary);
            height: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, var(--secondary), #2980b9);
            color: white;
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 0.5rem;
        }

        .stat-title {
            color: #6c757d;
            font-weight: 500;
            font-size: 0.9rem;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
        }

        .card-header {
            background: white;
            border-bottom: 1px solid #e9ecef;
            border-radius: 15px 15px 0 0 !important;
            padding: 1.25rem 1.5rem;
            font-weight: 600;
            color: var(--primary);
        }

        .car-img {
            height: 120px;
            width: 100%;
            object-fit: cover;
            border-radius: 10px;
        }

        .price-tag {
            font-weight: 700;
            color: var(--accent);
            font-size: 1.1rem;
        }

        .badge-status {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-confirmed { background: #d1ecf1; color: #0c5460; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-cancelled { background: #f8d7da; color: #721c24; }

        .message-item {
            padding: 1rem;
            border-bottom: 1px solid #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .message-item:hover {
            background-color: #f8f9fa;
        }

        .message-item.unread {
            background-color: #e3f2fd;
            border-left: 3px solid var(--secondary);
        }

        .notification-badge {
            background: var(--accent);
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.7rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-left: 5px;
        }

        .quick-action {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
            border: 2px solid transparent;
            height: 100%;
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .quick-action:hover {
            border-color: var(--secondary);
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            color: inherit;
            text-decoration: none;
        }

        .action-icon {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--secondary), #2980b9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            color: white;
            font-size: 1.8rem;
        }

        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #dee2e6;
        }

        .sidebar {
            position: sticky;
            top: 20px;
        }

        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--secondary);
        }
        
        .navbar-brand {
            font-weight: 700;
            color: var(--primary) !important;
        }
        
        .nav-link {
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <?php 
    // Header yang dimodifikasi untuk link beranda ke index.php
    ?>
    
    <!-- Custom Header untuk Dashboard -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="../index.php">
                <i class="fas fa-car me-2 text-primary"></i>
                <span class="fw-bold">Automarket</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">
                            <i class="fas fa-home me-1"></i>Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../cars.php">
                            <i class="fas fa-search me-1"></i>Cari Mobil
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="favorites.php"><i class="fas fa-heart me-2"></i>Favorit</a></li>
                            <li><a class="dropdown-item" href="my_bookings.php"><i class="fas fa-calendar-check me-2"></i>Booking Saya</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../profile.php"><i class="fas fa-cog me-2"></i>Pengaturan Profil</a></li>
                            <li><a class="dropdown-item text-danger" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Keluar</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid py-4">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 mb-4">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <?php if (!empty($_SESSION['foto_profil'])): ?>
                                <img src="../uploads/profiles/<?php echo $_SESSION['foto_profil']; ?>" class="user-avatar" alt="Profile">
                            <?php else: ?>
                                <div class="user-avatar mx-auto bg-light d-flex align-items-center justify-content-center">
                                    <i class="fas fa-user fa-2x text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></h5>
                        <p class="text-muted mb-3">Pembeli</p>
                        
                        <div class="list-group list-group-flush">
                            <a href="dashboard.php" class="list-group-item list-group-item-action active">
                                <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                            </a>
                            <a href="favorites.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-heart me-2"></i>Favorit Saya
                            </a>
                            <a href="my_bookings.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-calendar-check me-2"></i>Booking Saya
                            </a>
                            <a href="messages.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-comments me-2"></i>Pesan
                                <?php if (($stats['total_pesan_belum_dibaca'] ?? 0) > 0): ?>
                                    <span class="notification-badge"><?php echo $stats['total_pesan_belum_dibaca']; ?></span>
                                <?php endif; ?>
                            </a>
                            <a href="../profile.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-cog me-2"></i>Pengaturan Profil
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="card mt-4">
                    <div class="card-header">
                        <i class="fas fa-bolt me-2"></i>Aksi Cepat
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-6">
                                <a href="../cars.php" class="quick-action">
                                    <div class="action-icon">
                                        <i class="fas fa-search"></i>
                                    </div>
                                    <h6 class="mb-0">Cari Mobil</h6>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="favorites.php" class="quick-action">
                                    <div class="action-icon">
                                        <i class="fas fa-heart"></i>
                                    </div>
                                    <h6 class="mb-0">Lihat Favorit</h6>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="my_bookings.php" class="quick-action">
                                    <div class="action-icon">
                                        <i class="fas fa-calendar-check"></i>
                                    </div>
                                    <h6 class="mb-0">Booking Saya</h6>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="messages.php" class="quick-action">
                                    <div class="action-icon">
                                        <i class="fas fa-comments"></i>
                                    </div>
                                    <h6 class="mb-0">Pesan</h6>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <!-- Header -->
                <div class="dashboard-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h1 class="h3 mb-2">Selamat Datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</h1>
                            <p class="mb-0 opacity-75">Lihat perkembangan pencarian mobil impian Anda</p>
                        </div>
                        <div class="col-auto">
                            <div class="stat-icon">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-heart"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total_favorit'] ?? 0; ?></div>
                            <div class="stat-title">Mobil Favorit</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total_booking_aktif'] ?? 0; ?></div>
                            <div class="stat-title">Booking Aktif</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-comments"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total_pesan_belum_dibaca'] ?? 0; ?></div>
                            <div class="stat-title">Pesan Baru</div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-handshake"></i>
                            </div>
                            <div class="stat-number"><?php echo $stats['total_transaksi_selesai'] ?? 0; ?></div>
                            <div class="stat-title">Transaksi Selesai</div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Mobil Favorit -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-heart me-2"></i>Mobil Favorit Terbaru</span>
                                <a href="favorites.php" class="btn btn-sm btn-primary">Lihat Semua</a>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($mobil_favorit)): ?>
                                    <?php foreach ($mobil_favorit as $mobil): ?>
                                        <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                                            <?php
                                            // DAPATKAN FOTO UTAMA
                                            $foto_utama = '';
                                            if (!empty($mobil['foto_utama'])) {
                                                $foto_utama = $mobil['foto_utama'];
                                            } elseif (!empty($mobil['foto_mobil_utama'])) {
                                                $foto_utama = $mobil['foto_mobil_utama'];
                                            }
                                            
                                            $foto_url = '';
                                            if (!empty($foto_utama)) {
                                                $foto_path = '../uploads/cars/' . $foto_utama;
                                                if (file_exists($foto_path)) {
                                                    $foto_url = $foto_path;
                                                }
                                            }
                                            
                                            if (empty($foto_url)) {
                                                $foto_url = 'https://via.placeholder.com/120x90?text=No+Image';
                                            }
                                            ?>
                                            
                                            <img src="<?php echo $foto_url; ?>" 
                                                 class="car-img me-3" 
                                                 alt="<?php echo $mobil['merk'] . ' ' . $mobil['model']; ?>"
                                                 style="width: 120px; height: 90px;">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo $mobil['merk'] . ' ' . $mobil['model']; ?></h6>
                                                <p class="text-muted small mb-1">
                                                    <i class="fas fa-calendar-alt me-1"></i><?php echo $mobil['tahun']; ?> 
                                                    • <?php echo number_format($mobil['kilometer'] ?? 0); ?> km
                                                </p>
                                                <div class="price-tag">Rp <?php echo number_format($mobil['harga'], 0, ',', '.'); ?></div>
                                            </div>
                                            <a href="../car_detail.php?id=<?php echo $mobil['id']; ?>" class="btn btn-sm btn-outline-primary">Lihat</a>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="empty-state">
                                        <i class="fas fa-heart"></i>
                                        <h6>Belum ada mobil favorit</h6>
                                        <p class="mb-0">Tambahkan mobil ke favorit untuk melihatnya di sini</p>
                                        <a href="../cars.php" class="btn btn-primary mt-3">Cari Mobil</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Booking Aktif -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-calendar-check me-2"></i>Booking Aktif</span>
                                <a href="my_bookings.php" class="btn btn-sm btn-primary">Lihat Semua</a>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($booking_aktif)): ?>
                                    <?php foreach ($booking_aktif as $booking): ?>
                                        <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                                            <?php
                                            // DAPATKAN FOTO UTAMA untuk booking
                                            $foto_booking = '';
                                            if (!empty($booking['foto_mobil_utama'])) {
                                                $foto_booking = $booking['foto_mobil_utama'];
                                            }
                                            
                                            $foto_booking_url = '';
                                            if (!empty($foto_booking)) {
                                                $foto_path = '../uploads/cars/' . $foto_booking;
                                                if (file_exists($foto_path)) {
                                                    $foto_booking_url = $foto_path;
                                                }
                                            }
                                            
                                            if (empty($foto_booking_url)) {
                                                $foto_booking_url = 'https://via.placeholder.com/120x90?text=No+Image';
                                            }
                                            ?>
                                            
                                            <img src="<?php echo $foto_booking_url; ?>" 
                                                 class="car-img me-3" 
                                                 alt="<?php echo $booking['merk'] . ' ' . $booking['model']; ?>"
                                                 style="width: 120px; height: 90px;">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo $booking['merk'] . ' ' . $booking['model']; ?></h6>
                                                <p class="text-muted small mb-1">Penjual: <?php echo $booking['penjual_nama']; ?></p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge-status badge-<?php echo $booking['status']; ?>">
                                                        <?php echo ucfirst($booking['status']); ?>
                                                    </span>
                                                    <div class="price-tag small">Rp <?php echo number_format($booking['harga'], 0, ',', '.'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="empty-state">
                                        <i class="fas fa-calendar-check"></i>
                                        <h6>Tidak ada booking aktif</h6>
                                        <p class="mb-0">Booking mobil untuk melihatnya di sini</p>
                                        <a href="../cars.php" class="btn btn-primary mt-3">Cari Mobil</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    
                    <!-- Notifikasi -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-bell me-2"></i>Notifikasi Terbaru
                            </div>
                            <div class="card-body">
                                <?php if (!empty($notifikasi)): ?>
                                    <?php foreach ($notifikasi as $notif): ?>
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="flex-shrink-0">
                                                <div class="stat-icon" style="width: 40px; height: 40px; font-size: 1rem;">
                                                    <i class="fas fa-bell"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-0"><?php echo htmlspecialchars($notif['judul']); ?></h6>
                                                <p class="text-muted mb-1 small"><?php echo htmlspecialchars($notif['pesan']); ?></p>
                                                <small class="text-muted"><?php echo date('d M H:i', strtotime($notif['created_at'])); ?></small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="empty-state py-3">
                                        <i class="fas fa-bell"></i>
                                        <h6>Tidak ada notifikasi</h6>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5><i class="fas fa-car me-2"></i>Automarket</h5>
                    <p class="text-muted">Platform jual beli mobil terpercaya di Indonesia.</p>
                </div>
                <div class="col-md-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="../index.php" class="text-white text-decoration-none">Beranda</a></li>
                        <li><a href="../cars.php" class="text-white text-decoration-none">Cari Mobil</a></li>
                        <li><a href="../about.php" class="text-white text-decoration-none">Tentang Kami</a></li>
                        <li><a href="../contact.php" class="text-white text-decoration-none">Kontak</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Hubungi Kami</h5>
                    <p class="mb-1"><i class="fas fa-envelope me-2"></i> support@automarket.com</p>
                    <p class="mb-1"><i class="fas fa-phone me-2"></i> (021) 1234-5678</p>
                </div>
            </div>
            <hr class="bg-light">
            <div class="text-center">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> Automarket. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto refresh setiap 30 detik untuk update notifikasi
        function refreshDashboard() {
            fetch('../includes/refresh_dashboard.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update notification badges
                        const badges = document.querySelectorAll('.notification-badge');
                        if (badges.length > 0) {
                            badges.forEach(badge => {
                                if (data.unread_messages > 0) {
                                    badge.textContent = data.unread_messages;
                                    badge.style.display = 'inline-flex';
                                } else {
                                    badge.style.display = 'none';
                                }
                            });
                        }
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        // Refresh setiap 30 detik
        setInterval(refreshDashboard, 30000);

        // Animation for cards
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stat-card');
            
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    card.style.transition = 'all 0.5s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });

            // Initial refresh
            refreshDashboard();
        });
    </script>
</body>
</html>