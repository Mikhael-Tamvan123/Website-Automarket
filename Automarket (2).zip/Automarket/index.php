<?php
require_once 'config.php';
require_once 'includes/car_manager.php';
require_once 'includes/favorite_manager.php';

$recent_cars = $carManager->getRecentCars(6);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Automarket - Marketplace Jual Beli Mobil Terpercaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --accent: #e74c3c;
            --success: #27ae60;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-secondary: linear-gradient(135deg, #3498db 0%, #2c3e50 100%);
            --shadow: 0 10px 30px rgba(0,0,0,0.1);
            --shadow-hover: 0 20px 40px rgba(0,0,0,0.15);
        }

        * {
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }

        .navbar-brand {
            font-weight: 700;
            color: var(--primary) !important;
        }

        .hero-section {
            background: var(--gradient), url('https://images.unsplash.com/photo-1486496572940-2bb2341fdbdf?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
            padding: 150px 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.4);
            z-index: 1;
        }

        .hero-section .container {
            position: relative;
            z-index: 2;
        }

        .hero-section h1 {
            font-size: 4rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
        }

        .hero-section .lead {
            font-size: 1.4rem;
            font-weight: 300;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
        }

        .search-box {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--shadow);
            margin-top: 40px;
        }

        .card {
            border: none;
            border-radius: 20px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-hover);
        }

        .car-card {
            height: 100%;
        }

        .card-img-top {
            height: 250px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .car-card:hover .card-img-top {
            transform: scale(1.05);
        }

        .btn-primary {
            background: var(--gradient);
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
        }

        .btn-outline-primary {
            border-radius: 12px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .price-tag {
            font-weight: 700;
            color: var(--accent);
            font-size: 1.4rem;
        }

        .stats-section {
            background: var(--gradient);
            color: white;
            padding: 80px 0;
            text-align: center;
            border-radius: 0;
        }

        .stat-number {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .stat-label {
            font-size: 1.2rem;
            opacity: 0.9;
            font-weight: 500;
        }

        .feature-icon {
            width: 100px;
            height: 100px;
            background: var(--gradient);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            color: white;
            font-size: 2.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .feature-card {
            background: white;
            border-radius: 20px;
            padding: 40px 30px;
            text-align: center;
            height: 100%;
            transition: all 0.3s ease;
            border: none;
            box-shadow: var(--shadow);
            position: relative;
            overflow: hidden;
        }

        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: var(--gradient);
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-hover);
        }

        .feature-card:hover .feature-icon {
            transform: scale(1.1) rotate(5deg);
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 1rem;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 60px;
            height: 4px;
            background: var(--gradient);
            border-radius: 2px;
        }

        .section-title.center::after {
            left: 50%;
            transform: translateX(-50%);
        }

        .process-step {
            text-align: center;
            padding: 30px 20px;
            position: relative;
        }

        .step-number {
            width: 80px;
            height: 80px;
            background: var(--gradient);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            color: white;
            font-size: 2rem;
            font-weight: 700;
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
            position: relative;
            z-index: 2;
        }

        .process-connector {
            position: absolute;
            top: 40px;
            left: 50%;
            width: 100%;
            height: 3px;
            background: var(--gradient);
            z-index: 1;
        }

        .favorite-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            background: rgba(255, 255, 255, 0.95);
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            z-index: 3;
        }

        .favorite-btn:hover {
            background: white;
            transform: scale(1.1);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .favorite-btn.active {
            color: var(--accent);
        }

        .car-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: var(--gradient);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            z-index: 3;
        }

        .animate-on-scroll {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }

        .animate-on-scroll.animated {
            opacity: 1;
            transform: translateY(0);
        }

        .floating-element {
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        .value-badge {
            background: var(--gradient);
            color: white;
            padding: 10px 25px;
            border-radius: 25px;
            font-size: 1rem;
            margin: 5px;
            display: inline-block;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }

        .testimonial-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--shadow);
            text-align: center;
            height: 100%;
            transition: all 0.3s ease;
        }

        .testimonial-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-hover);
        }

        .testimonial-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 20px;
            border: 3px solid var(--gradient);
        }

        .rating {
            color: #ffc107;
            margin-bottom: 15px;
        }

        .car-image-placeholder {
            height: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3rem;
        }

        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2.5rem;
            }
            
            .hero-section {
                padding: 100px 0;
            }
            
            .process-connector {
                display: none;
            }
            
            .stat-number {
                font-size: 2.5rem;
            }
        }

        .booked-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(44, 62, 80, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 2px;
            z-index: 2;
            border-radius: 20px 20px 0 0;
        }

        .booked-overlay i {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }

        .card.booked {
            position: relative;
        }

        .card.booked::after {
            content: 'BOOKED';
            position: absolute;
            top: 20px;
            right: 20px;
            background: var(--accent);
            color: white;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
            z-index: 3;
            transform: rotate(15deg);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
        }

        .btn-disabled {
            opacity: 0.6;
            cursor: not-allowed !important;
        }




    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-3 fw-bold mb-4">Temukan Mobil Impian Anda</h1>
                    <p class="lead mb-4">Platform jual beli mobil terpercaya dengan proses yang mudah dan aman</p>
                    <div class="d-flex flex-wrap justify-content-center gap-3 mb-5">
                        <span class="value-badge"><i class="fas fa-shield-alt me-2"></i>Aman & Terpercaya</span>
                        <span class="value-badge"><i class="fas fa-bolt me-2"></i>Proses Cepat</span>
                        <span class="value-badge"><i class="fas fa-hand-holding-usd me-2"></i>Harga Terbaik</span>
                    </div>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="search-box animate-on-scroll">
                        <h4 class="mb-4 text-center"><i class="fas fa-search me-2"></i>Cari Mobil Impian Anda</h4>
                        <form action="cars.php" method="GET" class="row g-3">
                            <div class="col-md-8">
                                <input type="text" class="form-control form-control-lg" name="search" 
                                       placeholder="Cari berdasarkan merk, model, tahun, atau kota..." 
                                       style="border-radius: 12px;">
                            </div>
                            <div class="col-md-4">
                                <button class="btn btn-primary btn-lg w-100" type="submit">
                                    <i class="fas fa-search me-2"></i> Cari Mobil
                                </button>
                            </div>
                        </form>
                        <div class="text-center mt-3">
                            <a href="cars.php" class="text-decoration-none">Lihat semua mobil tersedia →</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4 animate-on-scroll">
                    <p class="stat-number">
                        <?php 
                        $sql = "SELECT COUNT(*) FROM mobil WHERE status = 'tersedia'";
                        echo $pdo->query($sql)->fetchColumn();
                        ?>
                    </p>
                    <p class="stat-label">Mobil Tersedia</p>
                </div>
                <div class="col-md-3 mb-4 animate-on-scroll">
                    <p class="stat-number">
                        <?php 
                        $sql = "SELECT COUNT(*) FROM users WHERE role = 'penjual'";
                        echo $pdo->query($sql)->fetchColumn();
                        ?>
                    </p>
                    <p class="stat-label">Penjual Terdaftar</p>
                </div>
                <div class="col-md-3 mb-4 animate-on-scroll">
                    <p class="stat-number">
                        <?php 
                        $sql = "SELECT COUNT(*) FROM transaksi_booking WHERE status = 'dikonfirmasi'";
                        echo $pdo->query($sql)->fetchColumn();
                        ?>
                    </p>
                    <p class="stat-label">Transaksi Berhasil</p>
                </div>
                <div class="col-md-3 mb-4 animate-on-scroll">
                    <p class="stat-number">12/6</p>
                    <p class="stat-label">Customer Support</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Cars Section -->
    <!-- Featured Cars Section -->
<section class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col">
                <h2 class="section-title">Mobil Terbaru</h2>
                <p class="lead">Pilihan mobil terbaru dengan kualitas terbaik dari penjual terpercaya</p>
            </div>
            <div class="col-auto">
                <a href="cars.php" class="btn btn-outline-primary btn-lg">
                    Lihat Semua <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
        
        <div class="row">
            <?php if(empty($recent_cars)): ?>
                <!-- Kode tetap sama -->
            <?php else: ?>
                <?php foreach($recent_cars as $car): ?>
                    <?php
                    // CEK STATUS BOOKING MOBIL
                    $is_booked = false;
                    $booking_status = '';
                    
                    // Query untuk mengecek apakah mobil sedang dibooking
                    $booking_check_sql = "SELECT status FROM transaksi_booking 
                                          WHERE mobil_id = :mobil_id 
                                          AND status IN ('pending', 'dikonfirmasi') 
                                          LIMIT 1";
                    $booking_check_stmt = $pdo->prepare($booking_check_sql);
                    $booking_check_stmt->execute([':mobil_id' => $car['id']]);
                    $booking_data = $booking_check_stmt->fetch();
                    
                    if ($booking_data) {
                        $is_booked = true;
                        $booking_status = $booking_data['status'] == 'pending' ? 'Booking Pending' : 'Sudah di Booking';
                    }
                    ?>
                    
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="card car-card animate-on-scroll">
                            <div class="position-relative">
                                <?php
                                // FIXED: Handle car photos properly
                                $car_photo = '';
                                
                                // Cek apakah mobil memiliki foto di kolom foto_mobil
                                if (!empty($car['foto_mobil'])) {
                                    $car_photo = 'uploads/cars/' . $car['foto_mobil'];
                                } 
                                // Jika tidak ada, coba ambil dari tabel foto_mobil
                                else {
                                    $photos = $carManager->getCarPhotos($car['id']);
                                    if (!empty($photos) && !empty($photos[0]['nama_file'])) {
                                        $car_photo = 'uploads/cars/' . $photos[0]['nama_file'];
                                    }
                                }
                                
                                // Jika masih tidak ada foto, gunakan placeholder
                                if (empty($car_photo) || !file_exists($car_photo)) {
                                    $car_photo = 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';
                                }
                                ?>
                                
                                <?php if (strpos($car_photo, 'http') === 0): ?>
                                    <img src="<?php echo $car_photo; ?>" class="card-img-top" alt="<?php echo $car['merk'] . ' ' . $car['model']; ?>">
                                <?php else: ?>
                                    <img src="<?php echo $car_photo; ?>" class="card-img-top" alt="<?php echo $car['merk'] . ' ' . $car['model']; ?>"
                                         onerror="this.src='https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'">
                                <?php endif; ?>
                                
                                <!-- BADGE STATUS MOBIL -->
                                <div class="car-badge">
                                    <?php if($is_booked): ?>
                                        <i class="fas fa-calendar-check me-1"></i> <?php echo $booking_status; ?>
                                    <?php else: ?>
                                        <i class="fas fa-bolt me-1"></i> Baru
                                    <?php endif; ?>
                                </div>
                                
                                <!-- OVERLAY UNTUK MOBIL YANG DIBOOKING -->
                                <?php if($is_booked): ?>
                                    <div class="booked-overlay" style="
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        background: rgba(44, 62, 80, 0.7);
                                        display: flex;
                                        align-items: center;
                                        justify-content: center;
                                        color: white;
                                        font-size: 1.5rem;
                                        font-weight: bold;
                                        text-transform: uppercase;
                                        letter-spacing: 2px;
                                        z-index: 2;
                                        border-radius: 20px 20px 0 0;
                                    ">
                                        <div class="text-center">
                                            <i class="fas fa-calendar-alt mb-2" style="font-size: 2.5rem;"></i>
                                            <div><?php echo $booking_status; ?></div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if(isset($_SESSION['user_id']) && $_SESSION['role'] == 'pembeli'): ?>
                                    <?php $is_favorite = $favoriteManager->isFavorite($_SESSION['user_id'], $car['id']); ?>
                                    <button class="favorite-btn <?php echo $is_favorite ? 'active' : ''; ?>" 
                                            data-car-id="<?php echo $car['id']; ?>"
                                            title="<?php echo $is_favorite ? 'Hapus dari favorit' : 'Tambahkan ke favorit'; ?>"
                                            <?php echo $is_booked ? 'disabled style="opacity: 0.5; cursor: not-allowed;"' : ''; ?>>
                                        <i class="<?php echo $is_favorite ? 'fas text-danger' : 'far'; ?> fa-heart"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                            
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title fw-bold"><?php echo $car['merk'] . ' ' . $car['model']; ?></h5>
                                <p class="card-text text-muted mb-3">
                                    <i class="fas fa-calendar-alt me-2"></i> <?php echo $car['tahun']; ?> 
                                    • <i class="fas fa-tachometer-alt ms-2 me-2"></i> <?php echo number_format($car['kilometer']); ?> km
                                    <br>
                                    <i class="fas fa-gas-pump me-2"></i> <?php echo ucfirst($car['bahan_bakar']); ?>
                                    • <i class="fas fa-cog ms-2 me-2"></i> <?php echo ucfirst(str_replace('_', ' ', $car['transmisi'])); ?>
                                </p>
                                
                                <!-- TAMBAHKAN NOTIFIKASI STATUS BOOKING DI BAWAH -->
                                <?php if($is_booked): ?>
                                    <div class="alert alert-warning mb-3 text-center py-2" style="border-radius: 10px;">
                                        <i class="fas fa-info-circle me-2"></i>
                                        Mobil ini <?php echo strtolower($booking_status); ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="mt-auto">
                                    <div class="price-tag mb-3">Rp <?php echo number_format($car['harga'], 0, ',', '.'); ?></div>
                                    
                                    <div class="d-grid gap-2">
                                        <a href="car_detail.php?id=<?php echo $car['id']; ?>" class="btn btn-primary">
                                            <i class="fas fa-eye me-2"></i> Lihat Detail
                                        </a>
                                        <?php if(isset($_SESSION['user_id'])): ?>
                                            <?php if($is_booked): ?>
                                                <button class="btn btn-outline-secondary" disabled>
                                                    <i class="fas fa-calendar-times me-2"></i> Tidak Tersedia
                                                </button>
                                            <?php else: ?>
                                                <a href="messages.php?to=<?php echo $car['penjual_id']; ?>&car=<?php echo $car['id']; ?>" class="btn btn-outline-primary">
                                                    <i class="fas fa-comment me-2"></i> Chat Penjual
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <button class="btn btn-outline-primary" onclick="showLoginAlert()">
                                                <i class="fas fa-comment me-2"></i> Chat Penjual
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

    <!-- Features Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="section-title center">Mengapa Memilih Automarket?</h2>
                    <p class="lead">Platform terbaik untuk jual beli mobil bekas dengan berbagai keunggulan</p>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="feature-card animate-on-scroll">
                        <div class="feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h4 class="mb-3">Aman & Terpercaya</h4>
                        <p class="mb-0">Sistem verifikasi ketat untuk penjual dan pembeli, memastikan transaksi yang aman dan terjamin.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="feature-card animate-on-scroll">
                        <div class="feature-icon">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <h4 class="mb-3">Tanpa Biaya Tambahan</h4>
                        <p class="mb-0">Gratis pasang iklan, tanpa komisi penjualan. Hanya bayar booking fee ketika deal.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="feature-card animate-on-scroll">
                        <div class="feature-icon">
                            <i class="fas fa-comments"></i>
                        </div>
                        <h4 class="mb-3">Chat Langsung</h4>
                        <p class="mb-0">Komunikasi langsung dengan penjual, negosiasi harga lebih mudah dan transparan.</p>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="feature-card animate-on-scroll">
                        <div class="feature-icon">
                            <i class="fas fa-file-contract"></i>
                        </div>
                        <h4 class="mb-3">Faktur Resmi</h4>
                        <p class="mb-0">Dapatkan faktur booking resmi yang dilindungi sistem dan memiliki kekuatan hukum.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="feature-card animate-on-scroll">
                        <div class="feature-icon">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <h4 class="mb-3">Mudah Digunakan</h4>
                        <p class="mb-0">Interface yang user-friendly, mudah digunakan oleh siapapun dengan berbagai latar belakang.</p>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="feature-card animate-on-scroll">
                        <div class="feature-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <h4 class="mb-3">Support 24/7</h4>
                        <p class="mb-0">Tim support siap membantu 7x24 jam untuk masalah transaksi dan keluhan pelanggan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="py-5">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="section-title center">Cara Kerja Automarket</h2>
                    <p class="lead">Proses jual beli mobil yang simpel, cepat, dan terpercaya</p>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="process-step animate-on-scroll text-center">
                        <div class="step-number">1</div>
                        <h5 class="fw-bold mb-3">Pencarian</h5>
                        <p class="mb-0">Cari mobil sesuai keinginan atau gunakan filter yang tersedia</p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="process-step animate-on-scroll text-center">
                        <div class="step-number">2</div>
                        <h5 class="fw-bold mb-3">Negosiasi & Booking</h5>
                        <p class="mb-0">Chat langsung dengan penjual/pembeli dan lakukan booking dengan DP</p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="process-step animate-on-scroll text-center">
                        <div class="step-number">3</div>
                        <h5 class="fw-bold mb-3">Transaksi & Serah Terima</h5>
                        <p class="mb-0">Bayar pelunasan dan selesaikan transaksi dengan aman</p>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-5">
                <a href="register.php" class="btn btn-primary btn-lg me-3">
                    <i class="fas fa-user-plus me-2"></i> Daftar Sekarang
                </a>
                <a href="about.php" class="btn btn-outline-primary btn-lg">
                    <i class="fas fa-info-circle me-2"></i> Pelajari Lebih Lanjut
                </a>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- JavaScript untuk Functionality -->
    <script>
        // Animation on scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.animate-on-scroll');
            elements.forEach(element => {
                const elementTop = element.getBoundingClientRect().top;
                const elementVisible = 150;
                
                if (elementTop < window.innerHeight - elementVisible) {
                    element.classList.add('animated');
                }
            });
        }

        // Initial check
        animateOnScroll();

        // Check on scroll
        window.addEventListener('scroll', animateOnScroll);

        // Favorite functionality
        document.addEventListener('DOMContentLoaded', function() {
            const favoriteButtons = document.querySelectorAll('.favorite-btn');
            
            favoriteButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    <?php if(!isset($_SESSION['user_id'])): ?>
                        showLoginAlert('Silakan login terlebih dahulu untuk menambahkan favorit');
                        return;
                    <?php endif; ?>
                    
                    const carId = this.getAttribute('data-car-id');
                    const icon = this.querySelector('i');
                    const isCurrentlyFavorite = icon.classList.contains('fas');
                    
                    // Show loading state
                    const originalHTML = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                    
                    fetch('includes/favorite_action.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'car_id=' + carId + '&action=toggle'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            if (data.is_favorite) {
                                // Menjadi favorit
                                this.innerHTML = '<i class="fas fa-heart text-danger"></i>';
                                this.classList.add('active');
                                this.title = 'Hapus dari favorit';
                                showToast('Mobil berhasil ditambahkan ke favorit', 'success');
                            } else {
                                // Bukan favorit lagi
                                this.innerHTML = '<i class="far fa-heart"></i>';
                                this.classList.remove('active');
                                this.title = 'Tambahkan ke favorit';
                                showToast('Mobil dihapus dari favorit', 'info');
                            }
                        } else {
                            showToast('Terjadi kesalahan: ' + (data.message || 'Unknown error'), 'error');
                            this.innerHTML = originalHTML;
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('Terjadi kesalahan saat memproses permintaan', 'error');
                        this.innerHTML = originalHTML;
                    });
                });
            });
        });

        function showLoginAlert(message = 'Silakan login terlebih dahulu') {
            if (confirm(message + '\n\nKlik OK untuk login')) {
                window.location.href = 'login.php';
            }
        }

        function showToast(message, type = 'info') {
            // Simple toast notification
            const toast = document.createElement('div');
            toast.className = `alert alert-${type === 'error' ? 'danger' : type} position-fixed`;
            toast.style.cssText = `
                top: 20px;
                right: 20px;
                z-index: 9999;
                min-width: 300px;
            `;
            toast.innerHTML = `
                <div class="d-flex justify-content-between align-items-center">
                    <span>${message}</span>
                    <button type="button" class="btn-close" onclick="this.parentElement.parentElement.remove()"></button>
                </div>
            `;
            
            document.body.appendChild(toast);
            
            // Auto remove after 3 seconds
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 3000);
        }

        // Search form enhancement
        const searchForm = document.querySelector('form[action="cars.php"]');
        if (searchForm) {
            searchForm.addEventListener('submit', function(e) {
                const searchInput = this.querySelector('input[name="search"]');
                if (searchInput.value.trim().length < 2) {
                    e.preventDefault();
                    showToast('Masukkan minimal 2 karakter untuk pencarian', 'warning');
                    searchInput.focus();
                }
            });
        }

        // Add loading animation for images
        document.querySelectorAll('img').forEach(img => {
            img.addEventListener('load', function() {
                this.style.opacity = '1';
            });
            img.style.transition = 'opacity 0.3s';
            img.style.opacity = '0';
        });
    </script>
</body>
</html>